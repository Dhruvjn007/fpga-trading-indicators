module top_basys3_uart (
    input wire clk,              // 100MHz onboard clock
    input wire sw,               // Single switch: SW0 for start/reset
    
    output wire [15:0] led,      // LEDs for status
    output wire uart_txd_out     // UART TX pin (USB-UART)
);

    // Internal signals
    wire rst;
    wire start;
    wire [31:0] price;
    wire price_valid;
    wire [31:0] ema9_out, ema12_out, ema26_out;
    wire [31:0] macd_out, signal_out, histogram_out;
    wire result_valid;
    wire [7:0] price_count;
    wire done;
    wire printing;
    wire uart_busy;
    
    // Switch assignments
    assign rst = sw;      // When SW0 is high: reset
    assign start = ~sw;   // When SW0 is low: start generating
    
    // Price generator instance
    // Price generator instance
    price_generator price_gen (
        .clk(clk),
        .rst(rst),
        .enable(start),
        .uart_busy(printing),  // ADD THIS LINE
        .price(price),
        .price_valid(price_valid),
        .price_count(price_count),
        .done(done)
    );
    
    // MACD calculator instance
    macd_parallel macd_inst (
        .clk(clk),
        .rst(rst),
        .price(price),
        .price_valid(price_valid),
        .ema9_out(ema9_out),
        .ema12_out(ema12_out),
        .ema26_out(ema26_out),
        .macd_out(macd_out),
        .signal_out(signal_out),
        .histogram_out(histogram_out),
        .result_valid(result_valid)
    );
    
    // UART printer instance
    uart_printer printer (
        .clk(clk),
        .rst(rst),
        .price_count(price_count),
        .price(price),
        .ema9(ema9_out),
        .ema12(ema12_out),
        .ema26(ema26_out),
        .macd(macd_out),
        .signal(signal_out),
        .histogram(histogram_out),
        .result_valid(result_valid),
        .done(done),
        .uart_tx(uart_txd_out),
        .printing(printing)
    );
    
    // LED assignments for status indication
    assign led[7:0] = price_count;     // Show price count on LEDs 0-7
    assign led[8] = price_valid;       // LED8: price being sent
    assign led[9] = result_valid;      // LED9: valid output
    assign led[10] = done;             // LED10: all 200 prices done
    assign led[11] = printing;         // LED11: UART transmitting
    assign led[15:12] = 4'b0;          // Unused LEDs

endmodule