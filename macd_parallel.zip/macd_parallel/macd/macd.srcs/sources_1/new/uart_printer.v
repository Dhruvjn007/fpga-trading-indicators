module uart_printer (
    input wire clk,
    input wire rst,
    input wire [7:0] price_count,
    input wire [31:0] price,
    input wire [31:0] ema9,
    input wire [31:0] ema12,
    input wire [31:0] ema26,
    input wire [31:0] macd,
    input wire [31:0] signal,
    input wire [31:0] histogram,
    input wire result_valid,
    input wire done,
    
    output wire uart_tx,
    output reg printing
);

    // UART signals
    reg [7:0] uart_data;
    reg uart_start;
    wire uart_busy;
    
    uart_tx uart_inst (
        .clk(clk),
        .rst(rst),
        .data(uart_data),
        .start(uart_start),
        .tx(uart_tx),
        .busy(uart_busy)
    );
    
    // State machine
    localparam WAIT_DATA = 0;
    localparam SEND_HEADER = 1;
    localparam SEND_LINE = 2;
    localparam SEND_DONE = 3;
    
    reg [7:0] state;
    reg [7:0] char_index;
    reg [7:0] saved_count;
    reg [31:0] saved_price, saved_ema9, saved_ema12, saved_ema26;
    reg [31:0] saved_macd, saved_signal, saved_hist;
    
    // Message buffer
    reg [7:0] message [0:127];
    reg [7:0] msg_len;
    
    // Print flags
    reg header_sent;
    reg last_valid;
    reg done_sent;
    
    // Fixed-point to ASCII conversion
    function [7:0] digit_to_ascii;
        input [3:0] digit;
        begin
            digit_to_ascii = "0" + digit;
        end
    endfunction
    
    // Format number as string (simplified - prints hex for now)
    task format_hex;
        input [31:0] value;
        input integer start_pos;
        integer i;
        reg [3:0] nibble;
        begin
            for (i = 7; i >= 0; i = i - 1) begin
                nibble = (value >> (i*4)) & 4'hF;
                if (nibble < 10)
                    message[start_pos + (7-i)] = "0" + nibble;
                else
                    message[start_pos + (7-i)] = "A" + (nibble - 10);
            end
        end
    endtask
    
    always @(posedge clk) begin
        if (rst) begin
            state <= WAIT_DATA;
            uart_start <= 0;
            printing <= 0;
            char_index <= 0;
            header_sent <= 0;
            last_valid <= 0;
            done_sent <= 0;
        end else begin
            case (state)
                WAIT_DATA: begin
                    uart_start <= 0;
                    
                    // Send header once
                    if (!header_sent) begin
                        // "MACD Calculator Started\r\n"
                        message[0] = "M"; message[1] = "A"; message[2] = "C"; message[3] = "D";
                        message[4] = " "; message[5] = "S"; message[6] = "t"; message[7] = "a";
                        message[8] = "r"; message[9] = "t"; message[10] = "e"; message[11] = "d";
                        message[12] = "\r"; message[13] = "\n";
                        msg_len = 14;
                        char_index = 0;
                        state <= SEND_HEADER;
                        printing <= 1;
                    end
                    // Print data when valid
                    else if (result_valid && !last_valid) begin
                        saved_count <= price_count;
                        saved_price <= price;
                        saved_ema9 <= ema9;
                        saved_ema12 <= ema12;
                        saved_ema26 <= ema26;
                        saved_macd <= macd;
                        saved_signal <= signal;
                        saved_hist <= histogram;
                        
                        // Format: "Price[XXX] = PPPPPPPP\r\n"
                        message[0] = "P"; message[1] = "r"; message[2] = "i";
                        message[3] = "c"; message[4] = "e"; message[5] = "[";
                        message[6] = "0" + (price_count / 100);
                        message[7] = "0" + ((price_count / 10) % 10);
                        message[8] = "0" + (price_count % 10);
                        message[9] = "]"; message[10] = "=";
                        format_hex(price, 11);
                        message[19] = "\r"; message[20] = "\n";
                        msg_len = 21;
                        char_index = 0;
                        state <= SEND_LINE;
                        printing <= 1;
                    end
                    // Send done message
                    else if (done && !done_sent) begin
                        message[0] = "D"; message[1] = "O"; message[2] = "N";
                        message[3] = "E"; message[4] = "!"; 
                        message[5] = "\r"; message[6] = "\n";
                        msg_len = 7;
                        char_index = 0;
                        state <= SEND_DONE;
                        printing <= 1;
                    end
                    
                    last_valid <= result_valid;
                end
                
                SEND_HEADER: begin
                    if (!uart_busy && !uart_start) begin
                        if (char_index < msg_len) begin
                            uart_data <= message[char_index];
                            uart_start <= 1;
                            char_index <= char_index + 1;
                        end else begin
                            header_sent <= 1;
                            printing <= 0;
                            state <= WAIT_DATA;
                        end
                    end else begin
                        uart_start <= 0;
                    end
                end
                
                SEND_LINE: begin
                    if (!uart_busy && !uart_start) begin
                        if (char_index < msg_len) begin
                            uart_data <= message[char_index];
                            uart_start <= 1;
                            char_index <= char_index + 1;
                        end else begin
                            printing <= 0;
                            state <= WAIT_DATA;
                        end
                    end else begin
                        uart_start <= 0;
                    end
                end
                
                SEND_DONE: begin
                    if (!uart_busy && !uart_start) begin
                        if (char_index < msg_len) begin
                            uart_data <= message[char_index];
                            uart_start <= 1;
                            char_index <= char_index + 1;
                        end else begin
                            done_sent <= 1;
                            printing <= 0;
                            state <= WAIT_DATA;
                        end
                    end else begin
                        uart_start <= 0;
                    end
                end
            endcase
        end
    end

endmodule