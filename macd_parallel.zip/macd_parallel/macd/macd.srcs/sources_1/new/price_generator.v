// ============================================================================
// FILE: price_generator.v (UPDATED VERSION)
// Generates 200 test prices with UART-friendly timing
// ============================================================================

module price_generator (
    input wire clk,
    input wire rst,
    input wire enable,              // Start generating prices
    input wire uart_busy,           // Wait for UART to be ready
    
    output reg [31:0] price,        // Q16.16 format
    output reg price_valid,
    output reg [7:0] price_count,   // How many prices generated
    output reg done                 // All 200 prices sent
);

    reg [7:0] counter;
    reg generating;
    reg [19:0] delay_counter;       // Delay between prices for UART
    localparam DELAY_CYCLES = 200000; // ~2ms delay @ 100MHz
    
    always @(posedge clk) begin
        if (rst) begin
            counter <= 8'd0;
            price_count <= 8'd0;
            price <= 32'd0;
            price_valid <= 1'b0;
            done <= 1'b0;
            generating <= 1'b0;
            delay_counter <= 0;
        end else begin
            if (enable && !generating && !done) begin
                generating <= 1'b1;
                counter <= 8'd0;
                price_count <= 8'd0;
                done <= 1'b0;
                delay_counter <= 0;
            end
            
            if (generating) begin
                // Only send new price when UART is ready and delay passed
                if (delay_counter < DELAY_CYCLES) begin
                    delay_counter <= delay_counter + 1;
                    price_valid <= 1'b0;
                end else if (!uart_busy) begin
                    delay_counter <= 0;
                    price_valid <= 1'b1;
                    
                    // Generate price pattern (similar to testbench)
                    if (counter < 10)
                        price <= (100 + counter) << 16;  // 100-109
                    else if (counter < 20)
                        price <= (90 + (counter - 10)) << 16;  // 90-99
                    else if (counter < 40)
                        price <= (100 + (counter - 20)) << 16;  // 100-119
                    else if (counter < 60)
                        price <= (90 + (counter - 40)) << 16;  // 90-109
                    else if (counter < 80)
                        price <= (100 + (counter - 60)) << 16;  // 100-119
                    else if (counter < 100)
                        price <= (90 + (counter - 80)) << 16;  // 90-109
                    else if (counter < 120)
                        price <= (100 + (counter - 100)) << 16;  // 100-119
                    else if (counter < 140)
                        price <= (90 + (counter - 120)) << 16;  // 90-109
                    else if (counter < 160)
                        price <= (100 + (counter - 140)) << 16;  // 100-119
                    else if (counter < 180)
                        price <= (90 + (counter - 160)) << 16;  // 90-109
                    else
                        price <= (100 + (counter - 180)) << 16;  // 100-119
                    
                    counter <= counter + 1;
                    price_count <= counter;  // Output current counter
                    
                    if (counter >= 199) begin
                        generating <= 1'b0;
                        done <= 1'b1;
                    end
                end else begin
                    price_valid <= 1'b0;
                end
            end else begin
                price_valid <= 1'b0;
            end
        end
    end

endmodule