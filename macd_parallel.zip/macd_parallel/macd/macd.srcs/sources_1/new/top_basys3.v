module top_basys3 (
    input wire clk,              // 100MHz onboard clock
    input wire sw,               // Single switch: SW0 for start/reset
    
    output wire [15:0] led       // LEDs for status
);

    // Internal signals
    wire rst;
    wire start;
    wire [31:0] price;
    wire price_valid;
    wire [31:0] ema9_out, ema12_out, ema26_out;
    wire [31:0] macd_out, signal_out, histogram_out;
    wire result_valid;
    wire [7:0] price_count;
    wire done;
    
    // Switch assignments
    assign rst = sw;      // When SW0 is high: reset
    assign start = ~sw;   // When SW0 is low: start generating
    
    // Price generator instance
    price_generator price_gen (
        .clk(clk),
        .rst(rst),
        .enable(start),
        .price(price),
        .price_valid(price_valid),
        .price_count(price_count),
        .done(done)
    );
    
    // MACD calculator instance
    macd_parallel macd_inst (
        .clk(clk),
        .rst(rst),
        .price(price),
        .price_valid(price_valid),
        .ema9_out(ema9_out),
        .ema12_out(ema12_out),
        .ema26_out(ema26_out),
        .macd_out(macd_out),
        .signal_out(signal_out),
        .histogram_out(histogram_out),
        .result_valid(result_valid)
    );
    
    // LED assignments for status indication
    assign led[7:0] = price_count;     // Show price count on LEDs 0-7
    assign led[8] = price_valid;       // LED8: price being sent
    assign led[9] = result_valid;      // LED9: valid output
    assign led[10] = done;             // LED10: all 200 prices done
    assign led[11] = start;            // LED11: generation active
    assign led[15:12] = 4'b0;          // Unused LEDs
    
    // Console output for simulation/debugging
    always @(posedge clk) begin
        if (result_valid && price_valid) begin
            $display("Price[%3d] = %6.2f | EMA9=%7.4f EMA12=%7.4f EMA26=%7.4f | MACD=%7.4f Signal=%7.4f Hist=%7.4f",
                price_count - 5,  // Account for pipeline delay
                $signed(price) / 65536.0,
                $signed(ema9_out) / 65536.0,
                $signed(ema12_out) / 65536.0,
                $signed(ema26_out) / 65536.0,
                $signed(macd_out) / 65536.0,
                $signed(signal_out) / 65536.0,
                $signed(histogram_out) / 65536.0
            );
        end
        
        if (done) begin
            $display("\n=== MACD Calculation Complete for 200 Prices ===");
            $display("Final MACD:      %7.4f", $signed(macd_out) / 65536.0);
            $display("Final Signal:    %7.4f", $signed(signal_out) / 65536.0);
            $display("Final Histogram: %7.4f", $signed(histogram_out) / 65536.0);
        end
    end

endmodule