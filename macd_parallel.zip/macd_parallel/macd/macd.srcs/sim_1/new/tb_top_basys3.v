module tb_top_basys3;

    reg clk;
    reg sw;
    wire [15:0] led;
    
    // Instantiate top module
    top_basys3 uut (
        .clk(clk),
        .sw(sw),
        .led(led)
    );
    
    // Clock generation - 100MHz (10ns period)
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end
    
    // Test sequence
    initial begin
        $display("\n========================================");
        $display("   BASYS3 MACD PROJECT - SIMULATION");
        $display("========================================\n");
        $display("Starting simulation with 200 prices...\n");
        $display("Price[ID] = Value | EMA9 EMA12 EMA26 | MACD Signal Histogram\n");
        
        // Start with reset
        sw = 1;  // Reset high
        #100;
        
        // Release reset to start generation
        sw = 0;  // Start generation
        $display("Price generation started (SW0 = 0)...\n");
        
        // Wait for completion (200 prices + pipeline delay)
        wait(uut.done == 1);
        #1000;  // Extra cycles to see final outputs
        
        $display("\n========================================");
        $display("   SIMULATION COMPLETE - ALL 200 PRICES PROCESSED");
        $display("========================================\n");
        
        $finish;
    end
    
    // Timeout watchdog
    initial begin
        #3000000;  // 3ms timeout (enough for 200 prices @ 10ns per cycle)
        $display("\n*** ERROR: Simulation timeout! ***\n");
        $finish;
    end
    
    // Optional: Monitor key signals (commented out for cleaner output)
    // Uncomment below line if you want to see LED status updates
    // initial begin
    //     $monitor("Time=%0t | Count=%3d | Valid=%b | Done=%b | LEDs=%b",
    //              $time, led[7:0], led[9], led[10], led);
    // end

endmodule