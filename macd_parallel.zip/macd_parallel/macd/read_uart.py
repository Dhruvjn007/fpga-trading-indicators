import serial
   
   # Change COM3 to your port
ser = serial.Serial('COM4', 115200, timeout=1)
   
print("Connected! Waiting for data...")
print("Press Ctrl+C to stop\n")
   
try:
       while True:
           if ser.in_waiting > 0:
               line = ser.readline().decode('utf-8', errors='ignore')
               print(line, end='')
except KeyboardInterrupt:
       print("\nStopped")
       ser.close()