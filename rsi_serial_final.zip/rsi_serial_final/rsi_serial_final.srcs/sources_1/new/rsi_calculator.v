// ============================================================================
// RSI Calculator Module - FIXED VERSION for Vivado
// Calculates 14-period RSI from price data
// Fixed-point arithmetic with proper scaling
// ============================================================================

module rsi_calculator #(
    parameter PRICE_WIDTH = 16,      // Input price width
    parameter RSI_WIDTH = 8,         // RSI output (0-100)
    parameter PERIOD = 14,           // Standard RSI period
    parameter FRAC_BITS = 6          // Fixed-point fractional bits (for RS scaling)
)(
    input wire clk,
    input wire rst,
    input wire enable,
    input wire [PRICE_WIDTH-1:0] price_in,
    input wire price_valid,
    
    output reg [RSI_WIDTH-1:0] rsi_out,
    output reg rsi_valid,
    output reg busy
);

// ============================================================================
// State definitions
// ============================================================================
localparam [3:0]
    ST_IDLE            = 4'd0,
    ST_CALC_DIFF       = 4'd1,
    ST_ACCUMULATE      = 4'd2,
    ST_CALC_INITIAL_AVG = 4'd3,
    ST_UPDATE_SMOOTH_AVG = 4'd4,
    ST_CALC_RS         = 4'd5,
    ST_CALC_RSI        = 4'd6,
    ST_OUTPUT          = 4'd7;

reg [3:0] state;

// ============================================================================
// Internal Registers - ALL DECLARED AT MODULE LEVEL
// ============================================================================

// Price tracking
reg [PRICE_WIDTH-1:0] prev_price;       // Previous day's closing price
reg [PRICE_WIDTH-1:0] curr_price;       // Current day's closing price

// Current period gain/loss
reg [PRICE_WIDTH-1:0] gain;             // Gain if price went up
reg [PRICE_WIDTH-1:0] loss;             // Loss if price went down

// Accumulators for first 14 periods
reg [PRICE_WIDTH+4-1:0] gain_sum;       // Sum of first 14 gains
reg [PRICE_WIDTH+4-1:0] loss_sum;       // Sum of first 14 losses

// Average Gain and Average Loss
reg [PRICE_WIDTH+4-1:0] avg_gain;       // Average gain
reg [PRICE_WIDTH+4-1:0] avg_loss;       // Average loss

// Relative Strength (scaled by 2^FRAC_BITS for precision)
reg [PRICE_WIDTH+FRAC_BITS+4-1:0] rs;   // RS = (avg_gain * 2^FRAC_BITS) / avg_loss

// RSI calculation temporary variables - MOVED HERE FROM ST_CALC_RSI BLOCK
reg [PRICE_WIDTH+FRAC_BITS+11-1:0] numerator;    // For RSI = (100 * rs)
reg [PRICE_WIDTH+FRAC_BITS+1-1:0] denominator;   // For RSI denominator

// Counters
reg [7:0] day_count;                    // Days processed (0 to 255)
reg first_period_done;                  // Flag: completed first 14 days

// ============================================================================
// Division by 14 Function - Paper's Method
// ============================================================================
function [PRICE_WIDTH+4-1:0] divide_by_14;
    input [PRICE_WIDTH+4+16-1:0] value;  // Input needs extra bits for multiplication
    reg [PRICE_WIDTH+4+16-1:0] temp;
    begin
        temp = value * 4681;              // Multiply by approximation constant
        divide_by_14 = temp >> 16;        // Divide by 65536 (shift right 16)
    end
endfunction

// ============================================================================
// Main State Machine
// ============================================================================

always @(posedge clk or posedge rst) begin
    if (rst) begin
        // Initialize all registers
        state <= ST_IDLE;
        prev_price <= 0;
        curr_price <= 0;
        gain <= 0;
        loss <= 0;
        gain_sum <= 0;
        loss_sum <= 0;
        avg_gain <= 0;
        avg_loss <= 0;
        rs <= 0;
        numerator <= 0;           // Initialize new variables
        denominator <= 0;         // Initialize new variables
        rsi_out <= 50;            // Neutral RSI on reset
        rsi_valid <= 0;
        busy <= 0;
        day_count <= 0;
        first_period_done <= 0;
        
    end else begin
        case (state)
            
            // ================================================================
            // IDLE: Wait for enable signal and valid price
            // ================================================================
            ST_IDLE: begin
                rsi_valid <= 0;         // Clear valid flag
                
                if (enable && price_valid) begin
                    busy <= 1;
                    curr_price <= price_in;
                    state <= ST_CALC_DIFF;
                end else begin
                    busy <= 0;
                end
            end
            
            // ================================================================
            // CALC_DIFF: Calculate gain or loss from price change
            // ================================================================
            ST_CALC_DIFF: begin
                if (day_count == 0) begin
                    // First day - establish baseline, no calculation possible
                    gain <= 0;
                    loss <= 0;
                    prev_price <= curr_price;
                    day_count <= day_count + 1;
                    state <= ST_IDLE;       // Get next price
                    
                end else begin
                    // Calculate gain or loss
                    if (curr_price > prev_price) begin
                        // Price increased - this is a gain
                        gain <= curr_price - prev_price;
                        loss <= 0;
                    end else if (curr_price < prev_price) begin
                        // Price decreased - this is a loss
                        gain <= 0;
                        loss <= prev_price - curr_price;
                    end else begin
                        // No change
                        gain <= 0;
                        loss <= 0;
                    end
                    
                    prev_price <= curr_price;
                    day_count <= day_count + 1;
                    
                    // Decide next state based on period
                    if (!first_period_done) begin
                        state <= ST_ACCUMULATE;     // Still in first 14 days
                    end else begin
                        state <= ST_UPDATE_SMOOTH_AVG;  // After first 14 days
                    end
                end
            end
            
            // ================================================================
            // ACCUMULATE: Sum gains/losses for first 14 days
            // ================================================================
            // CRITICAL: We need 14 CHANGES (days 1-14), which means 15 prices total
            // Day 0: baseline price (no change)
            // Day 1-14: 14 price changes
            // Day 15: Calculate first RSI
            ST_ACCUMULATE: begin
                gain_sum <= gain_sum + gain;
                loss_sum <= loss_sum + loss;
                
                if (day_count > PERIOD) begin
                    // Completed first 14 changes (15 prices total)
                    state <= ST_CALC_INITIAL_AVG;
                end else begin
                    // Need more data
                    state <= ST_IDLE;
                end
            end
            
            // ================================================================
            // CALC_INITIAL_AVG: Calculate first average (simple average)
            // ================================================================
            ST_CALC_INITIAL_AVG: begin
                avg_gain <= divide_by_14(gain_sum);
                avg_loss <= divide_by_14(loss_sum);
                first_period_done <= 1;
                state <= ST_CALC_RS;
            end
            
            // ================================================================
            // UPDATE_SMOOTH_AVG: Apply smoothing formula (after day 14)
            // ================================================================
            ST_UPDATE_SMOOTH_AVG: begin
                // Calculate new average gain: (old_avg * 13 + new_gain) / 14
                avg_gain <= divide_by_14((avg_gain * 13) + gain);
                
                // Calculate new average loss: (old_avg * 13 + new_loss) / 14
                avg_loss <= divide_by_14((avg_loss * 13) + loss);
                
                state <= ST_CALC_RS;
            end
            
            // ================================================================
            // CALC_RS: Calculate Relative Strength
            // ================================================================
            ST_CALC_RS: begin
                if (avg_loss == 0) begin
                    // All gains, no losses - RS is infinite
                    // Set to maximum representable value
                    rs <= {1'b1, {(PRICE_WIDTH+FRAC_BITS+3){1'b1}}};
                end else begin
                    // RS = (avg_gain * 2^FRAC_BITS) / avg_loss
                    // The shift left scales it up for precision
                    rs <= (avg_gain << FRAC_BITS) / avg_loss;
                end
                
                state <= ST_CALC_RSI;
            end
            
            // ================================================================
            // CALC_RSI: Calculate final RSI value
            // ================================================================
            // FIXED: Removed reg declarations from here - they're now at top
            // ================================================================
            ST_CALC_RSI: begin
                // Calculate numerator and denominator
                numerator = 100 * rs;
                denominator = rs + (1 << FRAC_BITS);  // Add 1.0 in scaled format
                
                if (denominator == 0) begin
                    // Should never happen, but safe default
                    rsi_out <= 50;
                end else begin
                    // Final RSI calculation
                    rsi_out <= numerator / denominator;
                end
                
                state <= ST_OUTPUT;
            end
            
            // ================================================================
            // OUTPUT: Assert valid signal and return to idle
            // ================================================================
            ST_OUTPUT: begin
                rsi_valid <= 1;
                busy <= 0;
                state <= ST_IDLE;
            end
            
            default: state <= ST_IDLE;
        endcase
    end
end

endmodule