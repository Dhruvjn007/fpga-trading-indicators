// ============================================================================
// RSI CALCULATOR TESTBENCH - Complete Beginner's Guide
// ============================================================================
// This testbench will:
// 1. Instantiate the RSI calculator module
// 2. Generate a clock signal
// 3. Send test price data
// 4. Monitor and display outputs
// 5. Verify correct RSI calculation
// ============================================================================

// STEP 1: Set time scale
// `timescale 1ns/1ps means:
// - All delays (#10) are in nanoseconds
// - Simulation precision is 1 picosecond
`timescale 1ns/1ps

module rsi_calculator_tb;  // Testbench module (note: no inputs/outputs!)

// ============================================================================
// STEP 2: Declare signals to connect to the RSI calculator
// ============================================================================

// Clock and reset
reg clk;           // Clock signal - we control this
reg rst;           // Reset signal - we control this

// Inputs to RSI calculator (we control these)
reg enable;
reg [15:0] price_in;      // 16-bit price (matches PRICE_WIDTH parameter)
reg price_valid;

// Outputs from RSI calculator (wires because module drives them)
wire [7:0] rsi_out;       // 8-bit RSI output (0-100)
wire rsi_valid;
wire busy;

// ============================================================================
// STEP 3: Instantiate the module under test (MUT)
// ============================================================================
// This creates a copy of your RSI calculator inside the testbench
// Syntax: module_name #(parameters) instance_name (port connections);

rsi_calculator #(
    .PRICE_WIDTH(16),     // Using 16-bit prices
    .RSI_WIDTH(8),        // 8-bit RSI output
    .PERIOD(14),          // Standard 14-period RSI
    .FRAC_BITS(6)         // 6 fractional bits for RS
) dut (                   // "dut" = Device Under Test
    .clk(clk),
    .rst(rst),
    .enable(enable),
    .price_in(price_in),
    .price_valid(price_valid),
    .rsi_out(rsi_out),
    .rsi_valid(rsi_valid),
    .busy(busy)
);

// ============================================================================
// STEP 4: Generate clock signal
// ============================================================================
// Clock toggles every 5ns, so period = 10ns (100MHz clock)
// This runs forever (or until $finish is called)

initial begin
    clk = 0;
    forever #5 clk = ~clk;  // Toggle clock every 5ns
end

// ============================================================================
// STEP 5: Test data - Real stock price example
// ============================================================================
// Using Apple stock prices from a 20-day period
// Prices are scaled to integers (e.g., $150.25 → 15025)

reg [15:0] test_prices [0:19];  // Array of 20 test prices

initial begin
    // Real price sequence showing an uptrend followed by downtrend
    test_prices[0]  = 16'd15000;  // Day 1: $150.00
    test_prices[1]  = 16'd15100;  // Day 2: $151.00 (gain)
    test_prices[2]  = 16'd15050;  // Day 3: $150.50 (loss)
    test_prices[3]  = 16'd15200;  // Day 4: $152.00 (gain)
    test_prices[4]  = 16'd15250;  // Day 5: $152.50 (gain)
    test_prices[5]  = 16'd15180;  // Day 6: $151.80 (loss)
    test_prices[6]  = 16'd15300;  // Day 7: $153.00 (gain)
    test_prices[7]  = 16'd15400;  // Day 8: $154.00 (gain)
    test_prices[8]  = 16'd15350;  // Day 9: $153.50 (loss)
    test_prices[9]  = 16'd15500;  // Day 10: $155.00 (gain)
    test_prices[10] = 16'd15550;  // Day 11: $155.50 (gain)
    test_prices[11] = 16'd15600;  // Day 12: $156.00 (gain)
    test_prices[12] = 16'd15580;  // Day 13: $155.80 (loss)
    test_prices[13] = 16'd15650;  // Day 14: $156.50 (gain)
    test_prices[14] = 16'd15700;  // Day 15: $157.00 (gain) - First RSI here
    test_prices[15] = 16'd15680;  // Day 16: $156.80 (loss)
    test_prices[16] = 16'd15620;  // Day 17: $156.20 (loss)
    test_prices[17] = 16'd15550;  // Day 18: $155.50 (loss)
    test_prices[18] = 16'd15500;  // Day 19: $155.00 (loss)
    test_prices[19] = 16'd15450;  // Day 20: $154.50 (loss)
end

// ============================================================================
// STEP 6: Main test sequence
// ============================================================================

integer i;  // Loop counter
integer num_tests;

initial begin
    // ========================================================================
    // SETUP: Create waveform dump file for viewing in simulator
    // ========================================================================
    $dumpfile("rsi_calculator.vcd");  // VCD = Value Change Dump
    $dumpvars(0, rsi_calculator_tb);  // Dump all signals in this module
    
    // Display header
    $display("\n========================================");
    $display("RSI CALCULATOR TESTBENCH");
    $display("========================================\n");
    
    num_tests = 20;  // Number of price points to test
    
    // ========================================================================
    // TEST 1: Reset sequence
    // ========================================================================
    $display("TEST 1: Reset and Initialization");
    $display("----------------------------------");
    
    // Initialize all inputs
    rst = 1;           // Assert reset
    enable = 0;
    price_in = 0;
    price_valid = 0;
    
    #20;               // Wait 20ns (2 clock cycles)
    rst = 0;           // Deassert reset
    #10;               // Wait another cycle
    
    $display("✓ Reset complete\n");
    
    // ========================================================================
    // TEST 2: Feed price data and calculate RSI
    // ========================================================================
    $display("TEST 2: Processing Price Data");
    $display("----------------------------------");
    $display("Day | Price  | RSI | Valid | Note");
    $display("----|--------|-----|-------|------------------");
    
    enable = 1;  // Enable the calculator
    
    // Feed all test prices
    for (i = 0; i < num_tests; i = i + 1) begin
        // Present new price
        @(posedge clk);  // Wait for clock edge
        price_in = test_prices[i];
        price_valid = 1;
        
        // Wait for processing (RSI calculator is busy)
        @(posedge clk);
        price_valid = 0;  // Deassert valid after one cycle
        
        // Wait for result
        wait(rsi_valid || !busy);  // Wait until done or not busy
        @(posedge clk);
        
        // Display result
        if (rsi_valid) begin
            $display("%3d | %6d | %3d |   1   | RSI calculated", 
                     i+1, test_prices[i], rsi_out);
        end else begin
            $display("%3d | %6d |  -  |   0   | Accumulating...", 
                     i+1, test_prices[i]);
        end
        
        #10;  // Small delay between prices
    end
    
    // ========================================================================
    // TEST 3: Verify RSI ranges
    // ========================================================================
    $display("\n\nTEST 3: Verification");
    $display("----------------------------------");
    
    if (rsi_out >= 0 && rsi_out <= 100) begin
        $display("✓ RSI in valid range [0, 100]: %d", rsi_out);
    end else begin
        $display("✗ ERROR: RSI out of range: %d", rsi_out);
    end
    
    // Expected behavior:
    // - Days 1-14: RSI valid = 0 (accumulating)
    // - Day 15+: RSI valid = 1
    // - Early days (uptrend): RSI should be high (>50)
    // - Later days (downtrend): RSI should decrease
    
    if (rsi_out < 50) begin
        $display("✓ Final RSI shows bearish trend: %d", rsi_out);
    end else begin
        $display("  Final RSI: %d", rsi_out);
    end
    
    // ========================================================================
    // TEST 4: Test with extreme values
    // ========================================================================
    $display("\n\nTEST 4: Extreme Value Test");
    $display("----------------------------------");
    
    // Reset for new test
    rst = 1;
    #20;
    rst = 0;
    #10;
    
    enable = 1;
    
    // Send 15 prices that only go up (should give RSI ≈ 100)
    $display("Sending 15 increasing prices (expect RSI ≈ 100)...");
    for (i = 0; i < 15; i = i + 1) begin
        @(posedge clk);
        price_in = 10000 + (i * 100);  // Steadily increasing
        price_valid = 1;
        @(posedge clk);
        price_valid = 0;
        wait(!busy);
        #10;
    end
    
    @(posedge clk);
    if (rsi_valid) begin
        $display("RSI after all gains: %d (expect near 100)", rsi_out);
        if (rsi_out > 90) begin
            $display("✓ RSI correctly shows strong bullish trend");
        end
    end
    
    // ========================================================================
    // Finish simulation
    // ========================================================================
    $display("\n========================================");
    $display("TESTBENCH COMPLETE");
    $display("========================================\n");
    
    #100;  // Wait a bit
    $finish;  // End simulation
end

// ============================================================================
// STEP 7: Monitor critical signals (optional but helpful)
// ============================================================================
// This automatically prints whenever these signals change

initial begin
    $monitor("Time=%0t | State=%d | Day=%d | busy=%b | rsi_valid=%b | rsi=%d",
             $time, dut.state, dut.day_count, busy, rsi_valid, rsi_out);
end

// ============================================================================
// STEP 8: Timeout watchdog (prevent infinite simulation)
// ============================================================================

initial begin
    #100000;  // 100 microseconds
    $display("\n✗ ERROR: Simulation timeout!");
    $finish;
end

endmodule