// Aroon Indicator Module
module aroon_indicator #(
    parameter WINDOW_SIZE = 25,
    parameter PRICE_WIDTH = 16
)(
    input wire clk,
    input wire rst,
    input wire [PRICE_WIDTH-1:0] price_in,
    input wire valid_in,
    output reg [7:0] aroon_up,
    output reg [7:0] aroon_down,
    output reg [1:0] signal,  // 00: HOLD, 01: BUY, 10: SELL
    output reg valid_out
);

    // Price history buffer
    reg [PRICE_WIDTH-1:0] price_buffer [0:WINDOW_SIZE-1];
    reg [7:0] buffer_count;
    integer i;
    
    // Position tracking
    reg [7:0] periods_since_high;
    reg [7:0] periods_since_low;
    
    // Previous signal for edge detection
    reg [1:0] prev_signal;
    
    // Variables for finding max/min (declare outside always block)
    reg [PRICE_WIDTH-1:0] max_price, min_price;
    reg [7:0] max_pos, min_pos;
    
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            buffer_count <= 0;
            aroon_up <= 0;
            aroon_down <= 0;
            signal <= 2'b00;  // HOLD
            valid_out <= 0;
            periods_since_high <= 0;
            periods_since_low <= 0;
            prev_signal <= 2'b00;
            max_price <= 0;
            min_price <= 0;
            max_pos <= 0;
            min_pos <= 0;
            for (i = 0; i < WINDOW_SIZE; i = i + 1) begin
                price_buffer[i] <= 0;
            end
        end else if (valid_in) begin
            // Shift buffer and add new price
            for (i = WINDOW_SIZE-1; i > 0; i = i - 1) begin
                price_buffer[i] <= price_buffer[i-1];
            end
            price_buffer[0] <= price_in;
            
            if (buffer_count < WINDOW_SIZE) begin
                buffer_count <= buffer_count + 1;
            end
            
            // Calculate Aroon after we have enough data
            if (buffer_count >= WINDOW_SIZE - 1) begin
                // Find position of highest and lowest prices
                max_price = price_buffer[0];
                min_price = price_buffer[0];
                max_pos = 0;
                min_pos = 0;
                
                for (i = 1; i < WINDOW_SIZE; i = i + 1) begin
                    if (price_buffer[i] >= max_price) begin
                        max_price = price_buffer[i];
                        max_pos = i;
                    end
                    if (price_buffer[i] <= min_price) begin
                        min_price = price_buffer[i];
                        min_pos = i;
                    end
                end
                
                periods_since_high = max_pos;
                periods_since_low = min_pos;
                
                // Calculate Aroon Up and Down (0-100 scale)
                aroon_up = ((WINDOW_SIZE - 1 - periods_since_high) * 100) / (WINDOW_SIZE - 1);
                aroon_down = ((WINDOW_SIZE - 1 - periods_since_low) * 100) / (WINDOW_SIZE - 1);
                
                // Generate trading signals
                if (aroon_up > 70 && aroon_down < 30) begin
                    signal <= 2'b01;  // BUY
                end else if (aroon_down > 70 && aroon_up < 30) begin
                    signal <= 2'b10;  // SELL
                end else begin
                    signal <= 2'b00;  // HOLD
                end
                
                prev_signal <= signal;
                valid_out <= 1;
            end else begin
                valid_out <= 0;
            end
        end
    end

endmodule