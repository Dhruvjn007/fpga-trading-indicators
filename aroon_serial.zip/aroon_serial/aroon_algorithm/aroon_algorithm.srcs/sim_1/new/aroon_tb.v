module aroon_tb;
    parameter WINDOW_SIZE = 25;
    parameter PRICE_WIDTH = 16;
    parameter NUM_PRICES = 200;
    
    reg clk;
    reg rst;
    reg [PRICE_WIDTH-1:0] price_in;
    reg valid_in;
    wire [7:0] aroon_up;
    wire [7:0] aroon_down;
    wire [1:0] signal;
    wire valid_out;
    
    // Test data storage
    reg [PRICE_WIDTH-1:0] prices [0:NUM_PRICES-1];
    integer i;
    integer start_time, end_time, total_time;
    integer valid_outputs;
    real latency_per_price, throughput;
    
    // Instantiate DUT
    aroon_indicator #(
        .WINDOW_SIZE(WINDOW_SIZE),
        .PRICE_WIDTH(PRICE_WIDTH)
    ) dut (
        .clk(clk),
        .rst(rst),
        .price_in(price_in),
        .valid_in(valid_in),
        .aroon_up(aroon_up),
        .aroon_down(aroon_down),
        .signal(signal),
        .valid_out(valid_out)
    );
    
    // Clock generation
    always #5 clk = ~clk;
    
    // Generate realistic price data (simulated stock prices)
    initial begin
        prices[0] = 16'd10000;  // Starting price: 100.00
        for (i = 1; i < NUM_PRICES; i = i + 1) begin
            // Simple trend with noise
            if (i < 50)
                prices[i] = prices[i-1] + ($random % 200) - 100;  // Sideways
            else if (i < 100)
                prices[i] = prices[i-1] + ($random % 150) + 50;   // Uptrend
            else if (i < 150)
                prices[i] = prices[i-1] + ($random % 200) - 100;  // Sideways
            else
                prices[i] = prices[i-1] - ($random % 150) - 50;   // Downtrend
            
            // Keep prices positive
            if (prices[i] < 5000) prices[i] = 5000;
            if (prices[i] > 20000) prices[i] = 20000;
        end
    end
    
    // Test stimulus
    initial begin
        clk = 0;
        rst = 1;
        valid_in = 0;
        price_in = 0;
        valid_outputs = 0;
        
        // Reset
        #20 rst = 0;
        #10;
        
        // Print header
        $display("\n========================================");
        $display("AROON INDICATOR SIMULATION");
        $display("Window Size: %0d", WINDOW_SIZE);
        $display("Number of Prices: %0d", NUM_PRICES);
        $display("========================================\n");
        $display("S.No. |  Price  | Aroon Up | Aroon Down | Signal");
        $display("------|---------|----------|------------|--------");
        
        start_time = $time;
        
        // Feed prices
        for (i = 0; i < NUM_PRICES; i = i + 1) begin
            @(posedge clk);
            price_in = prices[i];
            valid_in = 1;
            
            @(posedge clk);
            #1;  // Wait for output to settle
            
            if (valid_out) begin
                valid_outputs = valid_outputs + 1;
                $display("%5d | %7d | %8d | %10d | %s",
                    i + 1,
                    price_in,
                    aroon_up,
                    aroon_down,
                    signal == 2'b01 ? "BUY" : 
                    signal == 2'b10 ? "SELL" : "HOLD");
            end else begin
                $display("%5d | %7d |    -     |     -      | INIT",
                    i + 1, price_in);
            end
        end
        
        valid_in = 0;
        end_time = $time;
        total_time = end_time - start_time;
        
        // Calculate metrics
        latency_per_price = total_time / (NUM_PRICES * 1.0);
        throughput = (NUM_PRICES * 1.0) / total_time;
        
        // Print summary
        $display("\n========================================");
        $display("PERFORMANCE METRICS");
        $display("========================================");
        $display("Total Computation Time: %0d ns", total_time);
        $display("Total Prices Processed: %0d", NUM_PRICES);
        $display("Valid Outputs Generated: %0d", valid_outputs);
        $display("Latency per Price: %.2f ns", latency_per_price);
        $display("Throughput: %.6f prices/ns", throughput);
        $display("Throughput: %.2f MHz (prices/us)", throughput * 1000);
        $display("Clock Period: 10 ns (100 MHz)");
        $display("Cycles per Price: %.1f", latency_per_price / 10.0);
        $display("========================================\n");
        
        #100;
        $finish;
    end
    
    // Optional: Waveform dump
    initial begin
        $dumpfile("aroon_tb.vcd");
        $dumpvars(0, aroon_tb);
    end

endmodule