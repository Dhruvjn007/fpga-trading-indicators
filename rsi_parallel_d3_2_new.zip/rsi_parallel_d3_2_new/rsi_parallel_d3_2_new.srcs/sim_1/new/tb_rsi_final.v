//==============================================================================
// FINAL CORRECTED TESTBENCH
// File 3 of 3: tb_rsi_final.v
// Properly timed for 32-stage divider with collision protection
//==============================================================================

`timescale 1ns/1ps

module tb_rsi_final;

    parameter DATA_WIDTH = 32;
    parameter FRAC_BITS = 16;
    parameter CLK_PERIOD = 10;
    parameter NUM_DAYS = 30;
    
    reg clk;
    reg rst_n;
    reg start;
    reg [DATA_WIDTH-1:0] close_price;
    wire [DATA_WIDTH-1:0] rsi_value;
    wire valid;
    wire [1:0] decision;
    
    reg [DATA_WIDTH-1:0] test_prices [0:NUM_DAYS-1];
    integer day_count;
    
    real ref_prices [0:NUM_DAYS-1];
    real ref_gains [0:NUM_DAYS-1];
    real ref_losses [0:NUM_DAYS-1];
    real ref_avg_gain, ref_avg_loss, ref_rs, ref_rsi;
    
    reg [DATA_WIDTH-1:0] captured_rsi [0:NUM_DAYS-1];
    reg [1:0] captured_decision [0:NUM_DAYS-1];
    integer valid_count;
    integer first_valid_day;
    
    integer results_file;
    real hw_rsi, error;
    real RSI_TOLERANCE = 3.0;
    
    function real fixed_to_real;
        input [DATA_WIDTH-1:0] fixed_val;
        begin
            fixed_to_real = $itor(fixed_val) / (1 << FRAC_BITS);
        end
    endfunction
    
    function [DATA_WIDTH-1:0] real_to_fixed;
        input real r;
        begin
            real_to_fixed = $rtoi(r * (1 << FRAC_BITS));
        end
    endfunction
    
    always @(posedge clk) begin
        if (!rst_n) begin
            valid_count <= 0;
            first_valid_day <= -1;
        end else if (valid) begin
            if (first_valid_day == -1) begin
                first_valid_day <= day_count;
                $display("\n[INFO] First valid RSI at day %0d", day_count);
            end
            
            captured_rsi[valid_count] <= rsi_value;
            captured_decision[valid_count] <= decision;
            valid_count <= valid_count + 1;
            
            $display("  [VALID #%0d] Day %2d: RSI=%0d.%02d, Decision=%s",
                valid_count + 1,
                day_count,
                rsi_value >> FRAC_BITS,
                ((rsi_value & 16'hFFFF) * 100) >> FRAC_BITS,
                decision == 2'b01 ? "BUY " :
                decision == 2'b10 ? "SELL" : "HOLD");
        end
    end
    
    task calculate_reference_rsi;
        input integer num_days;
        real gain_sum, loss_sum;
        real curr_gain, curr_loss;
        integer i;
        begin
            ref_gains[0] = 0.0;
            ref_losses[0] = 0.0;
            
            for (i = 1; i < num_days; i = i + 1) begin
                if (ref_prices[i] > ref_prices[i-1]) begin
                    ref_gains[i] = ref_prices[i] - ref_prices[i-1];
                    ref_losses[i] = 0.0;
                end else begin
                    ref_gains[i] = 0.0;
                    ref_losses[i] = ref_prices[i-1] - ref_prices[i];
                end
            end
            
            if (num_days >= 15) begin
                gain_sum = 0.0;
                loss_sum = 0.0;
                
                for (i = 1; i <= 14; i = i + 1) begin
                    gain_sum = gain_sum + ref_gains[i];
                    loss_sum = loss_sum + ref_losses[i];
                end
                
                ref_avg_gain = gain_sum / 14.0;
                ref_avg_loss = loss_sum / 14.0;
                
                if (ref_avg_loss == 0.0) begin
                    ref_rsi = 100.0;
                end else begin
                    ref_rs = ref_avg_gain / ref_avg_loss;
                    ref_rsi = 100.0 - (100.0 / (1.0 + ref_rs));
                end
                
                $display("\n  Day 14 Initial RSI:");
                $display("    Avg Gain = %.6f", ref_avg_gain);
                $display("    Avg Loss = %.6f", ref_avg_loss);
                $display("    RS       = %.6f", ref_rs);
                $display("    RSI      = %.2f", ref_rsi);
            end
            
            for (i = 15; i < num_days; i = i + 1) begin
                curr_gain = ref_gains[i];
                curr_loss = ref_losses[i];
                
                ref_avg_gain = (ref_avg_gain * 13.0 + curr_gain) / 14.0;
                ref_avg_loss = (ref_avg_loss * 13.0 + curr_loss) / 14.0;
                
                if (ref_avg_loss == 0.0) begin
                    ref_rsi = 100.0;
                end else begin
                    ref_rs = ref_avg_gain / ref_avg_loss;
                    ref_rsi = 100.0 - (100.0 / (1.0 + ref_rs));
                end
            end
            
            $display("\n  Final Day %0d RSI:", num_days-1);
            $display("    Avg Gain = %.6f", ref_avg_gain);
            $display("    Avg Loss = %.6f", ref_avg_loss);
            $display("    RS       = %.6f", ref_rs);
            $display("    RSI      = %.2f", ref_rsi);
        end
    endtask
    
    rsi_calculator #(
        .DATA_WIDTH(DATA_WIDTH),
        .FRAC_BITS(FRAC_BITS)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .close_price(close_price),
        .rsi_value(rsi_value),
        .valid(valid),
        .decision(decision)
    );
    
    initial begin
        clk = 0;
        forever #(CLK_PERIOD/2) clk = ~clk;
    end
    
       //======================================================================
    // Modified generate_test_prices: Up → Sideways → Down
    //   - Days  0-9  : gentle uptrend
    //   - Days 10-19 : choppy / sideways (some up, some down)
    //   - Days 20-29 : clear downtrend
    //======================================================================
    task generate_test_prices;
        real base_price, volatility, noise;
        integer i;
        begin
            base_price  = 100.0;
            volatility  = 0.8;

            $display("\nGenerating 30-day test prices (Up / Sideways / Down):");
            $display("  Day | Price");
            $display("  ----|-------");

            for (i = 0; i < NUM_DAYS; i = i + 1) begin
                if (i < 10) begin
                    // Days 0-9: UP trend
                    // approx +0.8 per day
                    noise        = $sin(i * 0.30) * volatility;
                    ref_prices[i] = base_price + i * 0.8 + noise;

                end else if (i < 20) begin
                    // Days 10-19: SIDEWAYS / CHOPPY
                    // small net trend, lots of oscillation
                    noise        = $sin(i * 0.70) * (1.5 * volatility);
                    ref_prices[i] = base_price + 10 * 0.8
                                    + (i-10) * 0.1   // tiny drift
                                    + noise;

                end else begin
                    // Days 20-29: DOWN trend
                    // approx -0.7 per day
                    noise        = $sin(i * 0.40) * volatility;
                    ref_prices[i] = base_price + 10 * 0.8
                                    + 10 * 0.1
                                    - (i-20) * 0.7   // falling prices
                                    + noise;
                end

                test_prices[i] = real_to_fixed(ref_prices[i]);

                // Same printing style as before
                if (i < 5 || i >= NUM_DAYS-5) begin
                    $display("  %3d | %7.2f", i, ref_prices[i]);
                end else if (i == 5) begin
                    $display("  ... | ...");
                end
            end
        end
    endtask

    
    initial begin
        rst_n = 0;
        start = 0;
        close_price = 0;
        valid_count = 0;
        first_valid_day = -1;
        
        results_file = $fopen("rsi_final_results.txt", "w");
        $fwrite(results_file, "================================================================\n");
        $fwrite(results_file, "    RSI Final Test Results (32-stage divider)                  \n");
        $fwrite(results_file, "================================================================\n\n");
        
        $display("================================================================");
        $display("  RSI Final Test - 32-Stage Exact Divider");
        $display("================================================================");
        
        generate_test_prices();
        
        $display("\n[INFO] Applying reset...");
        #(CLK_PERIOD*5);
        rst_n = 1;
        #(CLK_PERIOD*2);
        
        $display("[INFO] Feeding prices...\n");
        
        //======================================================================
        // CRITICAL: Proper timing for 32-stage divider + collision protection
        //======================================================================
        for (day_count = 0; day_count < NUM_DAYS; day_count = day_count + 1) begin
            @(posedge clk);
            #1;
            
            start = 1;
            close_price = test_prices[day_count];
            
            $display("[DAY %2d] Feeding Price = %7.2f", 
                day_count,
                fixed_to_real(close_price));
            
            @(posedge clk);
            #1;
            start = 0;
            close_price = 0;
            
            // CRITICAL: Wait long enough for 32-stage divider
            // 32 cycles (divider) + margin for collision protection
            if (day_count >= 14) begin
                repeat(40) @(posedge clk);  // 32 + 8 margin
            end else begin
                repeat(2) @(posedge clk);
            end
        end
        
        $display("\n[INFO] Waiting for final results...");
        repeat(50) @(posedge clk);
        
        $display("\n================================================================");
        $display("  Verification: HW vs Software Reference");
        $display("================================================================");
        
        calculate_reference_rsi(NUM_DAYS);
        
        $display("\n[RESULTS]");
        $display("  Expected first valid: Day 14");
        $display("  Actual first valid:   Day %0d %s", 
                 first_valid_day, 
                 (first_valid_day == 14) ? "✓" : "✗");
        
        $display("\n  Expected valid count: 16 (days 14-29)");
        $display("  Actual valid count:   %0d %s", 
                 valid_count,
                 (valid_count == 16) ? "✓" : "✗");
        
        if (valid_count > 0) begin
            hw_rsi = fixed_to_real(captured_rsi[valid_count-1]);
            error = hw_rsi - ref_rsi;
            
            $display("\n  Final RSI Comparison:");
            $display("    Hardware RSI:  %.2f", hw_rsi);
            $display("    Reference RSI: %.2f", ref_rsi);
            $display("    Error:         %.2f", error);
            $display("    Tolerance:     ±%.2f", RSI_TOLERANCE);
            
            $fwrite(results_file, "First Valid Day:    %0d (expected 14)\n", first_valid_day);
            $fwrite(results_file, "Valid Count:        %0d (expected 16)\n", valid_count);
            $fwrite(results_file, "Final HW RSI:       %.2f\n", hw_rsi);
            $fwrite(results_file, "Final Ref RSI:      %.2f\n", ref_rsi);
            $fwrite(results_file, "Error:              %.2f\n\n", error);
            $fwrite(results_file, "Detailed Results:\n");
            $fwrite(results_file, "Valid# | Day | HW RSI | Decision\n");
            $fwrite(results_file, "-------|-----|--------|----------\n");
            
            for (day_count = 0; day_count < valid_count; day_count = day_count + 1) begin
                $fwrite(results_file, "%6d | %3d | %6.2f | %s\n",
                    day_count + 1,
                    14 + day_count,
                    fixed_to_real(captured_rsi[day_count]),
                    captured_decision[day_count] == 2'b01 ? "BUY " :
                    captured_decision[day_count] == 2'b10 ? "SELL" : "HOLD");
            end
            
            if ((hw_rsi >= 0.0) && (hw_rsi <= 100.0) && 
                (error >= -RSI_TOLERANCE) && (error <= RSI_TOLERANCE) &&
                (first_valid_day == 14) && (valid_count == 16)) begin
                $display("\n✓✓✓ TEST PASSED ✓✓✓");
                $fwrite(results_file, "\nResult: PASS\n");
            end else begin
                $display("\n✗✗✗ TEST FAILED ✗✗✗");
                $fwrite(results_file, "\nResult: FAIL\n");
            end
        end else begin
            $display("\n✗✗✗ NO VALID OUTPUTS ✗✗✗");
            $fwrite(results_file, "\nResult: FAIL - No outputs\n");
        end
        
        $fwrite(results_file, "================================================================\n");
        $fclose(results_file);
        
        $display("================================================================");
        $display("Results saved to: rsi_final_results.txt\n");
        
        $finish;
    end
    
    initial begin
        #(CLK_PERIOD * 100000);
        $display("\n✗ Simulation timeout!\n");
        $finish;
    end
    
    initial begin
        $dumpfile("rsi_final_waves.vcd");
        $dumpvars(0, tb_rsi_final);
    end

endmodule