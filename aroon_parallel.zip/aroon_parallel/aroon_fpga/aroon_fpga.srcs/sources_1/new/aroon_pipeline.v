// AROON Pipeline - Main Module (Fixed Version)
module aroon_pipeline #(
    parameter DATA_WIDTH = 16,
    parameter PERIOD = 14  // 14-day period for AROON
)(
    input wire clk,
    input wire rst,
    input wire [DATA_WIDTH-1:0] high_price,
    input wire [DATA_WIDTH-1:0] low_price,
    input wire data_valid,
    output reg [7:0] aroon_up,
    output reg [7:0] aroon_down,
    output reg result_valid
);

    // Stage 1: Input registers (need PERIOD+1 for comparison)
    reg [DATA_WIDTH-1:0] hp_reg [0:PERIOD];
    reg [DATA_WIDTH-1:0] lp_reg [0:PERIOD];
    reg [4:0] count;
    reg stage1_valid;
    
    // Stage 2: Find max high and min low positions
    reg [4:0] max_pos_temp;
    reg [4:0] min_pos_temp;
    reg [4:0] max_pos;
    reg [4:0] min_pos;
    reg stage2_valid;
    
    integer i;
    
    // Stage 1: Shift register for price data
    always @(posedge clk) begin
        if (rst) begin
            for (i = 0; i <= PERIOD; i = i + 1) begin
                hp_reg[i] <= 0;
                lp_reg[i] <= 0;
            end
            count <= 0;
            stage1_valid <= 0;
        end else if (data_valid) begin
            // Shift data
            for (i = PERIOD; i > 0; i = i - 1) begin
                hp_reg[i] <= hp_reg[i-1];
                lp_reg[i] <= lp_reg[i-1];
            end
            hp_reg[0] <= high_price;
            lp_reg[0] <= low_price;
            
            if (count < PERIOD) begin
                count <= count + 1;
                stage1_valid <= 0;
            end else begin
                stage1_valid <= 1;
            end
        end else begin
            stage1_valid <= 0;
        end
    end
    
    // Stage 2: Find positions of max high and min low
    always @(posedge clk) begin
        if (rst) begin
            max_pos <= 0;
            min_pos <= 0;
            stage2_valid <= 0;
        end else if (stage1_valid) begin
            // Initialize with position 0
            max_pos_temp = 0;
            min_pos_temp = 0;
            
            // Find max high position (most recent occurrence)
            for (i = PERIOD; i >= 0; i = i - 1) begin
                if (hp_reg[i] >= hp_reg[max_pos_temp]) begin
                    max_pos_temp = i;
                end
            end
            
            // Find min low position (most recent occurrence)
            for (i = PERIOD; i >= 0; i = i - 1) begin
                if (lp_reg[i] <= lp_reg[min_pos_temp]) begin
                    min_pos_temp = i;
                end
            end
            
            max_pos <= max_pos_temp;
            min_pos <= min_pos_temp;
            stage2_valid <= 1;
        end else begin
            stage2_valid <= 0;
        end
    end
    
    // Stage 3: Calculate AROON Up and Down
    always @(posedge clk) begin
        if (rst) begin
            aroon_up <= 0;
            aroon_down <= 0;
            result_valid <= 0;
        end else if (stage2_valid) begin
            // AROON Up = ((PERIOD - periods_since_high) / PERIOD) * 100
            // Since max_pos is the index, periods_since_high = max_pos
            aroon_up <= ((PERIOD - max_pos) * 100) / PERIOD;
            
            // AROON Down = ((PERIOD - periods_since_low) / PERIOD) * 100
            aroon_down <= ((PERIOD - min_pos) * 100) / PERIOD;
            
            result_valid <= 1;
        end else begin
            result_valid <= 0;
        end
    end

endmodule