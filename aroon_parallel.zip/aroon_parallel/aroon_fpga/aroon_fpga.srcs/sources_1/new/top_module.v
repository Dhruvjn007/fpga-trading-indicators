// Top Module for Basys 3 FPGA Board
module top_module(
    input wire clk,           // 100 MHz clock
    input wire btnC,          // Center button for reset
    input wire RsRx,          // UART RX
    output wire RsTx,         // UART TX
    output wire [15:0] led    // LEDs for status
);

    // Parameters
    parameter DATA_WIDTH = 16;
    parameter PERIOD = 14;
    
    // Reset signal
    wire rst;
    assign rst = btnC;
    
    // UART signals
    wire [7:0] rx_data;
    wire rx_ready;
    wire [7:0] tx_data;
    wire tx_start;
    wire tx_busy;
    
    // AROON signals
    reg [DATA_WIDTH-1:0] high_price;
    reg [DATA_WIDTH-1:0] low_price;
    reg data_valid;
    wire [7:0] aroon_up;
    wire [7:0] aroon_down;
    wire result_valid;
    
    // State machine for receiving data
    localparam IDLE = 3'd0;
    localparam RX_HIGH_MSB = 3'd1;
    localparam RX_HIGH_LSB = 3'd2;
    localparam RX_LOW_MSB = 3'd3;
    localparam RX_LOW_LSB = 3'd4;
    localparam PROCESS = 3'd5;
    
    reg [2:0] rx_state;
    reg [7:0] high_msb, high_lsb;
    reg [7:0] low_msb, low_lsb;
    
    // TX state machine
    localparam TX_IDLE = 3'd0;
    localparam TX_AROON_UP = 3'd1;
    localparam TX_COMMA1 = 3'd2;
    localparam TX_AROON_DOWN = 3'd3;
    localparam TX_NEWLINE = 3'd4;
    localparam TX_WAIT = 3'd5;
    
    reg [2:0] tx_state;
    reg [7:0] tx_data_reg;
    reg tx_start_reg;
    
    // Timing counters
    reg [31:0] data_count;
    reg [63:0] cycle_count;
    reg [63:0] start_cycle;
    reg [63:0] end_cycle;
    
    // Status LEDs
    assign led[0] = rx_ready;
    assign led[1] = result_valid;
    assign led[2] = tx_busy;
    assign led[3] = (rx_state != IDLE);
    assign led[4] = (tx_state != TX_IDLE);
    assign led[15:8] = aroon_up;
    
    // UART RX instantiation
    uart_rx #(
        .CLK_FREQ(100_000_000),
        .BAUD_RATE(115200)
    ) uart_rx_inst (
        .clk(clk),
        .rst(rst),
        .rx(RsRx),
        .rx_data(rx_data),
        .rx_ready(rx_ready)
    );
    
    // UART TX instantiation
    uart_tx #(
        .CLK_FREQ(100_000_000),
        .BAUD_RATE(115200)
    ) uart_tx_inst (
        .clk(clk),
        .rst(rst),
        .tx_data(tx_data),
        .tx_start(tx_start),
        .tx(RsTx),
        .tx_busy(tx_busy)
    );
    
    // AROON Pipeline instantiation
    aroon_pipeline #(
        .DATA_WIDTH(DATA_WIDTH),
        .PERIOD(PERIOD)
    ) aroon_inst (
        .clk(clk),
        .rst(rst),
        .high_price(high_price),
        .low_price(low_price),
        .data_valid(data_valid),
        .aroon_up(aroon_up),
        .aroon_down(aroon_down),
        .result_valid(result_valid)
    );
    
    assign tx_data = tx_data_reg;
    assign tx_start = tx_start_reg;
    
    // Cycle counter
    always @(posedge clk) begin
        if (rst)
            cycle_count <= 0;
        else
            cycle_count <= cycle_count + 1;
    end
    
    // RX State Machine - Receive price data
    always @(posedge clk) begin
        if (rst) begin
            rx_state <= IDLE;
            high_price <= 0;
            low_price <= 0;
            data_valid <= 0;
            high_msb <= 0;
            high_lsb <= 0;
            low_msb <= 0;
            low_lsb <= 0;
            data_count <= 0;
            start_cycle <= 0;
        end else begin
            data_valid <= 0;
            
            case (rx_state)
                IDLE: begin
                    if (rx_ready) begin
                        high_msb <= rx_data;
                        rx_state <= RX_HIGH_MSB;
                        if (data_count == 0)
                            start_cycle <= cycle_count;
                    end
                end
                
                RX_HIGH_MSB: begin
                    if (rx_ready) begin
                        high_lsb <= rx_data;
                        rx_state <= RX_HIGH_LSB;
                    end
                end
                
                RX_HIGH_LSB: begin
                    if (rx_ready) begin
                        low_msb <= rx_data;
                        rx_state <= RX_LOW_MSB;
                    end
                end
                
                RX_LOW_MSB: begin
                    if (rx_ready) begin
                        low_lsb <= rx_data;
                        rx_state <= RX_LOW_LSB;
                    end
                end
                
                RX_LOW_LSB: begin
                    high_price <= {high_msb, high_lsb};
                    low_price <= {low_msb, low_lsb};
                    data_valid <= 1;
                    data_count <= data_count + 1;
                    rx_state <= IDLE;
                end
                
                default: rx_state <= IDLE;
            endcase
        end
    end
    
    // TX State Machine - Send results
    always @(posedge clk) begin
        if (rst) begin
            tx_state <= TX_IDLE;
            tx_data_reg <= 0;
            tx_start_reg <= 0;
            end_cycle <= 0;
        end else begin
            tx_start_reg <= 0;
            
            case (tx_state)
                TX_IDLE: begin
                    if (result_valid) begin
                        end_cycle <= cycle_count;
                        tx_data_reg <= aroon_up;
                        tx_start_reg <= 1;
                        tx_state <= TX_AROON_UP;
                    end
                end
                
                TX_AROON_UP: begin
                    if (!tx_busy && !tx_start_reg) begin
                        tx_data_reg <= 8'd44; // ','
                        tx_start_reg <= 1;
                        tx_state <= TX_COMMA1;
                    end
                end
                
                TX_COMMA1: begin
                    if (!tx_busy && !tx_start_reg) begin
                        tx_data_reg <= aroon_down;
                        tx_start_reg <= 1;
                        tx_state <= TX_AROON_DOWN;
                    end
                end
                
                TX_AROON_DOWN: begin
                    if (!tx_busy && !tx_start_reg) begin
                        tx_data_reg <= 8'd10; // '\n'
                        tx_start_reg <= 1;
                        tx_state <= TX_NEWLINE;
                    end
                end
                
                TX_NEWLINE: begin
                    if (!tx_busy && !tx_start_reg) begin
                        tx_state <= TX_IDLE;
                    end
                end
                
                default: tx_state <= TX_IDLE;
            endcase
        end
    end

endmodule