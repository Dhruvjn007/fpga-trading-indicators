#!/usr/bin/env python3
"""
AROON FPGA Monitor
Receives AROON indicator values from Basys 3 FPGA via UART
"""

import serial
import time
import sys

# Configuration
SERIAL_PORT = 'COM4'  # Change to your port
BAUD_RATE = 115200
TIMEOUT = 2

# Sample price data (High, Low pairs) - 16-bit values
price_data = [
    (100, 90),
    (105, 95),
    (110, 100),
    (115, 105),
    (120, 110),
    (125, 115),
    (130, 120),
    (128, 118),
    (126, 116),
    (124, 114),
    (122, 112),
    (120, 110),
    (118, 108),
    (116, 106),
    (114, 104),
    (120, 110),
    (125, 115),
    (130, 120),
    (135, 125),
    (140, 130),
]

def send_price_data(ser, high, low):
    """Send 16-bit high and low prices to FPGA (4 bytes total)"""
    data = bytes([
        (high >> 8) & 0xFF,  # High MSB
        high & 0xFF,         # High LSB
        (low >> 8) & 0xFF,   # Low MSB
        low & 0xFF           # Low LSB
    ])
    ser.write(data)
    ser.flush()

def read_with_timeout(ser, timeout_sec=0.5):
    """Read a line with timeout"""
    start_time = time.time()
    buffer = b''
    
    while (time.time() - start_time) < timeout_sec:
        if ser.in_waiting > 0:
            byte = ser.read(1)
            if byte == b'\n':
                return buffer.decode('ascii', errors='ignore')
            buffer += byte
        time.sleep(0.001)
    
    return None

def main():
    try:
        # Open serial port
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=TIMEOUT)
        print(f"Connected to {SERIAL_PORT} at {BAUD_RATE} baud")
        
        # Clear any pending data
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        time.sleep(1)
        
        result_count = 0
        start_time = time.time()
        first_result_time = None
        
        print("\nSending price data to FPGA...\n")
        
        # Send all price data with small delays
        for idx, (high, low) in enumerate(price_data):
            send_price_data(ser, high, low)
            print(f"Sent {idx+1:2d}: High={high:3d}, Low={low:3d}")
            time.sleep(0.05)  # 50ms between sends
            
            # Check for any incoming data
            result = read_with_timeout(ser, 0.02)
            if result:
                try:
                    if ',' in result:
                        parts = result.strip().split(',')
                        if len(parts) == 2:
                            aroon_up = int(parts[0])
                            aroon_down = int(parts[1])
                            result_count += 1
                            if first_result_time is None:
                                first_result_time = time.time()
                            print(f"  → Output: AROON Up={aroon_up:3d}, AROON Down={aroon_down:3d}")
                except (ValueError, IndexError):
                    pass
        
        print("\nAll data sent. Waiting for remaining results...\n")
        
        # Wait for remaining results (with longer timeout)
        wait_start = time.time()
        while (time.time() - wait_start) < 3.0:
            result = read_with_timeout(ser, 0.1)
            if result:
                try:
                    if ',' in result:
                        parts = result.strip().split(',')
                        if len(parts) == 2:
                            aroon_up = int(parts[0])
                            aroon_down = int(parts[1])
                            result_count += 1
                            if first_result_time is None:
                                first_result_time = time.time()
                            print(f"Output: AROON Up={aroon_up:3d}, AROON Down={aroon_down:3d}")
                            wait_start = time.time()  # Reset timeout on new data
                except (ValueError, IndexError):
                    pass
        
        end_time = time.time()
        
        # Calculate metrics
        total_time = end_time - start_time
        
        print("\n" + "="*50)
        print("RESULTS")
        print("="*50)
        print(f"Output: Received {result_count} AROON results")
        
        if first_result_time and result_count > 0:
            latency = first_result_time - start_time
            throughput = result_count / total_time
            print(f"Latency: {latency:.3f} seconds")
            print(f"Throughput: {throughput:.2f} results/second")
        else:
            print("\nNo results received. Troubleshooting:")
            print("1. Check that FPGA is programmed (LEDs should light up)")
            print("2. Press reset button (btnC) on Basys 3")
            print("3. Verify UART connections")
            print("4. Check Device Manager for correct COM port")
        
        ser.close()
        
    except serial.SerialException as e:
        print(f"Error: Could not open serial port {SERIAL_PORT}")
        print(f"Details: {e}")
        print("\nPlease check:")
        print("1. FPGA is connected via USB")
        print("2. Correct COM port in Device Manager")
        print("3. No other program is using the port")
        print("4. Try unplugging and replugging the USB cable")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        if 'ser' in locals():
            ser.close()
        sys.exit(0)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()