module macd_parallel (
    input wire clk,
    input wire rst,
    input wire [31:0] price,           // Q16.16 format
    input wire price_valid,            // New price available
    
    output reg [31:0] ema9_out,        // For visualization
    output reg [31:0] ema12_out,       // For visualization
    output reg [31:0] ema26_out,       // For visualization
    output reg [31:0] macd_out,
    output reg [31:0] signal_out,
    output reg [31:0] histogram_out,
    output reg result_valid
);

    // Q16 fixed-point alphas (signed)
    // alpha_N = 2/(N+1) for proper EMA calculation
    localparam signed [31:0] alpha_9      = 32'h00003333; // 0.2
    localparam signed [31:0] alpha_12     = 32'h000027AE; // ~0.1538
    localparam signed [31:0] alpha_26     = 32'h000012FC; // ~0.0741
    localparam signed [31:0] alpha_9_bar  = 32'h0000CCCD; // 0.8
    localparam signed [31:0] alpha_12_bar = 32'h0000D852; // ~0.8462
    localparam signed [31:0] alpha_26_bar = 32'h0000ED04; // ~0.9259

    // Global state registers (updated every cycle)
    reg [31:0] ema9_state;
    reg [31:0] ema12_state;
    reg [31:0] ema26_state;
    reg [31:0] signal_state;
    reg [7:0] sample_counter;

    // Pipeline Stage 1: Price Input
    reg [31:0] stage1_price;
    reg stage1_valid;

    // Pipeline Stage 2: EMA Calculations
    reg [31:0] stage2_ema9;
    reg [31:0] stage2_ema12;
    reg [31:0] stage2_ema26;
    reg stage2_valid;

    // Pipeline Stage 3: MACD Calculation
    reg signed [31:0] stage3_macd;
    reg [31:0] stage3_ema9;   // Pass through for output
    reg [31:0] stage3_ema12;  // Pass through for output
    reg [31:0] stage3_ema26;  // Pass through for output
    reg stage3_valid;

    // Pipeline Stage 4: Signal Calculation
    reg signed [31:0] stage4_macd;    // Pass through
    reg signed [31:0] stage4_signal;
    reg [31:0] stage4_ema9;   // Pass through for output
    reg [31:0] stage4_ema12;  // Pass through for output
    reg [31:0] stage4_ema26;  // Pass through for output
    reg stage4_valid;

    // Pipeline Stage 5: Histogram Calculation
    reg signed [31:0] stage5_macd;
    reg signed [31:0] stage5_signal;
    reg signed [31:0] stage5_histogram;
    reg [31:0] stage5_ema9;   // Pass through for output
    reg [31:0] stage5_ema12;  // Pass through for output
    reg [31:0] stage5_ema26;  // Pass through for output
    reg stage5_valid;

    // Intermediate calculation wires
    wire signed [63:0] ema9_prod1, ema9_prod2;
    wire signed [63:0] ema12_prod1, ema12_prod2;
    wire signed [63:0] ema26_prod1, ema26_prod2;
    wire signed [63:0] signal_prod1, signal_prod2;

    // EMA9 calculation wires
    assign ema9_prod1 = $signed(stage1_price) * $signed(alpha_9);
    assign ema9_prod2 = $signed(ema9_state) * $signed(alpha_9_bar);

    // EMA12 calculation wires
    assign ema12_prod1 = $signed(stage1_price) * $signed(alpha_12);
    assign ema12_prod2 = $signed(ema12_state) * $signed(alpha_12_bar);

    // EMA26 calculation wires
    assign ema26_prod1 = $signed(stage1_price) * $signed(alpha_26);
    assign ema26_prod2 = $signed(ema26_state) * $signed(alpha_26_bar);

    // Signal calculation wires
    assign signal_prod1 = $signed(stage3_macd) * $signed(alpha_9);
    assign signal_prod2 = $signed(signal_state) * $signed(alpha_9_bar);

    // Sample counter for valid signal
    always @(posedge clk) begin
        if (rst) begin
            sample_counter <= 0;
        end else if (price_valid && sample_counter < 255) begin
            sample_counter <= sample_counter + 1;
        end
    end

    // Main pipeline logic
    always @(posedge clk) begin
        if (rst) begin
            // Reset all state registers
            ema9_state   <= 32'd0;
            ema12_state  <= 32'd0;
            ema26_state  <= 32'd0;
            signal_state <= 32'd0;

            // Reset pipeline registers
            stage1_price <= 32'd0;
            stage1_valid <= 1'b0;

            stage2_ema9  <= 32'd0;
            stage2_ema12 <= 32'd0;
            stage2_ema26 <= 32'd0;
            stage2_valid <= 1'b0;

            stage3_macd  <= 32'd0;
            stage3_ema9  <= 32'd0;
            stage3_ema12 <= 32'd0;
            stage3_ema26 <= 32'd0;
            stage3_valid <= 1'b0;

            stage4_macd   <= 32'd0;
            stage4_signal <= 32'd0;
            stage4_ema9   <= 32'd0;
            stage4_ema12  <= 32'd0;
            stage4_ema26  <= 32'd0;
            stage4_valid  <= 1'b0;

            stage5_macd      <= 32'd0;
            stage5_signal    <= 32'd0;
            stage5_histogram <= 32'd0;
            stage5_ema9      <= 32'd0;
            stage5_ema12     <= 32'd0;
            stage5_ema26     <= 32'd0;
            stage5_valid     <= 1'b0;

        end else begin
            // ===== STAGE 1: Price Input =====
            stage1_price <= price;
            stage1_valid <= price_valid;

            // Initialize EMAs with first price
            if (sample_counter == 0 && price_valid) begin
                ema9_state   <= price;
                ema12_state  <= price;
                ema26_state  <= price;
            end

            // ===== STAGE 2: EMA Calculations =====
            if (stage1_valid) begin
                // Calculate new EMAs (Q16.16 × Q16.16 = Q32.32, shift right by 16)
                stage2_ema9  <= (ema9_prod1 + ema9_prod2) >>> 16;
                stage2_ema12 <= (ema12_prod1 + ema12_prod2) >>> 16;
                stage2_ema26 <= (ema26_prod1 + ema26_prod2) >>> 16;
                stage2_valid <= 1'b1;

                // Update global EMA states
                ema9_state   <= (ema9_prod1 + ema9_prod2) >>> 16;
                ema12_state  <= (ema12_prod1 + ema12_prod2) >>> 16;
                ema26_state  <= (ema26_prod1 + ema26_prod2) >>> 16;
            end else begin
                stage2_valid <= 1'b0;
            end

            // ===== STAGE 3: MACD Calculation =====
            if (stage2_valid) begin
                stage3_macd  <= $signed(stage2_ema12) - $signed(stage2_ema26);
                stage3_ema9  <= stage2_ema9;
                stage3_ema12 <= stage2_ema12;
                stage3_ema26 <= stage2_ema26;
                stage3_valid <= 1'b1;
            end else begin
                stage3_valid <= 1'b0;
            end

            // ===== STAGE 4: Signal Line Calculation =====
            if (stage3_valid) begin
                // Calculate Signal (EMA9 of MACD)
                stage4_signal <= (signal_prod1 + signal_prod2) >>> 16;
                stage4_macd   <= stage3_macd;
                stage4_ema9   <= stage3_ema9;
                stage4_ema12  <= stage3_ema12;
                stage4_ema26  <= stage3_ema26;
                stage4_valid  <= 1'b1;

                // Update global signal state
                signal_state <= (signal_prod1 + signal_prod2) >>> 16;
            end else begin
                stage4_valid <= 1'b0;
            end

            // ===== STAGE 5: Histogram Calculation =====
            if (stage4_valid) begin
                stage5_histogram <= $signed(stage4_macd) - $signed(stage4_signal);
                stage5_macd      <= stage4_macd;
                stage5_signal    <= stage4_signal;
                stage5_ema9      <= stage4_ema9;
                stage5_ema12     <= stage4_ema12;
                stage5_ema26     <= stage4_ema26;
                stage5_valid     <= 1'b1;
            end else begin
                stage5_valid <= 1'b0;
            end
        end
    end

    // Output assignment
    always @(*) begin
        ema9_out      = stage5_ema9;
        ema12_out     = stage5_ema12;
        ema26_out     = stage5_ema26;
        macd_out      = stage5_macd;
        signal_out    = stage5_signal;
        histogram_out = stage5_histogram;
        // Valid after 26 samples (EMA26) + 9 samples (Signal) + 5 pipeline stages = 40
        result_valid  = stage5_valid && (sample_counter >= 40);
    end

endmodule