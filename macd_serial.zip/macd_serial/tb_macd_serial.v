`timescale 1ns/1ps

module tb_macd_serial;

  // Clock / reset / control
  reg clk;
  reg reset;
  reg start;
  reg price_valid;

  // price (signed Q16 fixed point)
  reg signed [31:0] price;

  // outputs from DUT
  wire signed [31:0] ema_9;
  wire signed [31:0] ema_12;
  wire signed [31:0] ema_26;
  wire signed [31:0] macd;
  wire signed [31:0] signal_line;  // Added signal line
  wire signed [31:0] histogram;
  wire               macd_valid;
  integer price_int;

  // instantiate DUT
  macd_serial uut (
    .clk(clk),
    .reset(reset),
    .start(start),
    .price_valid(price_valid),
    .price(price),
    .ema_9(ema_9),
    .ema_12(ema_12),
    .ema_26(ema_26),
    .macd(macd),
    .signal_line(signal_line),  // Connected signal line
    .histogram(histogram),
    .macd_valid(macd_valid)
  );

  // generate clock: 10 ns period
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  // helper function to convert Q16 fixed to real for nice printing
  function real q16_to_real;
    input signed [31:0] v;
    begin
      q16_to_real = $itor(v) / 65536.0;
    end
  endfunction

  integer i;
  integer num_samples = 120;

  initial begin
    // waveform dump
    $dumpfile("tb_macd_serial.vcd");
    $dumpvars(0, tb_macd_serial);

    // initial control values
    reset = 1;
    start = 0;
    price_valid = 0;
    price = 0;

    // Wait exactly two positive edges while reset asserted
    @(posedge clk);
    @(posedge clk);
    reset = 0;
    
    // Wait one more cycle, then assert start and keep it high
    @(posedge clk);
    start = 1;
    price_valid = 1; // Keep price_valid high

    // Print header with signal line added
    $display("\ntime(ns) | cycle | price |  ema12   ema26    macd   signal   hist  | valid");
    $display("-----------------------------------------------------------------------------------");

    // Feed a sequence of prices
    for (i = 0; i < num_samples; i = i + 1) begin
      // Create price pattern
      price_int = 100 + ((i % 20) - 10);
      if ((i % 37) == 0) price_int = price_int - 15;
      if ((i % 53) == 0) price_int = price_int + 20;

      price = $signed(price_int <<< 16); // Q16 fixed point

      // Wait for FSM to process this sample
      // The FSM takes about 8 clock cycles per sample
      repeat(10) @(posedge clk);

      // Print current state after processing - now includes signal line
      $display("%0t | %3d | %5.2f | %7.4f %7.4f %7.4f %7.4f %7.4f |   %0b",
               $time, i,
               q16_to_real(price),
               q16_to_real(ema_12), q16_to_real(ema_26),
               q16_to_real(macd), q16_to_real(signal_line), q16_to_real(histogram),
               macd_valid
      );
      
      // Highlight when macd_valid becomes 1
      if (i == 26 && macd_valid) begin
        $display(">>> MACD VALID ASSERTED at sample %0d <<<", i);
      end
    end

    // Additional cycles to observe final state
    repeat(20) @(posedge clk);
    
    $display("\n========================");
    $display("Test complete!");
    $display("Final MACD valid: %0b", macd_valid);
    $display("Final MACD value: %0.4f", q16_to_real(macd));
    $display("Final Signal Line: %0.4f", q16_to_real(signal_line));
    $display("Final Histogram: %0.4f", q16_to_real(histogram));
    $display("Final EMA9 (price): %0.4f", q16_to_real(ema_9));
    $display("Final EMA12: %0.4f", q16_to_real(ema_12));
    $display("Final EMA26: %0.4f", q16_to_real(ema_26));
    $display("========================\n");
    
    $finish;
  end

endmodule