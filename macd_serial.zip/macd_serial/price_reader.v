module price_reader #(
    parameter DATA_WIDTH = 32,
    parameter DEPTH = 256,               // number of values in file
    parameter FILE_NAME = "prices.hex"
)(
    input clk,
    input start,
    output reg [DATA_WIDTH-1:0] price,
    output reg done, price_valid
);

    // Memory to hold prices
    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];
    integer i;
    integer index;

    // Load hex file once at simulation start
    initial begin
        $readmemh(FILE_NAME, mem);
        index = 0;
        done = 0;
    end

    // On clock edge, if start is high, read sequentially
    always @(posedge clk) begin
        if (start && !done) begin
            price <= mem[index];
            index <= index + 1;
            if (index == DEPTH-1)
                done <= 1;
        end
    end

endmodule