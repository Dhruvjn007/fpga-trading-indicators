module tb_macd_parallel;

    // Clock and reset
    reg clk;
    reg rst;
    
    // DUT inputs
    reg [31:0] price;
    reg price_valid;
    
    // DUT outputs
    wire [31:0] ema9_out;
    wire [31:0] ema12_out;
    wire [31:0] ema26_out;
    wire [31:0] macd_out;
    wire [31:0] signal_out;
    wire [31:0] histogram_out;
    wire result_valid;
    
    // Test variables
    integer i;
    integer cycle_count;
    reg [31:0] test_prices [0:119];  // 120 test prices
    
    // Instantiate DUT
    macd_parallel dut (
        .clk(clk),
        .rst(rst),
        .price(price),
        .price_valid(price_valid),
        .ema9_out(ema9_out),
        .ema12_out(ema12_out),
        .ema26_out(ema26_out),
        .macd_out(macd_out),
        .signal_out(signal_out),
        .histogram_out(histogram_out),
        .result_valid(result_valid)
    );
    
    // Clock generation - 10ns period (100 MHz)
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end
    
    // Fixed-point to real conversion for display
    function real fixed_to_real;
        input [31:0] fixed_val;
        begin
            fixed_to_real = $signed(fixed_val) / 65536.0;
        end
    endfunction
    
    // Initialize test prices (same as serial version)
    initial begin
        // Prices from 100 to 109 (hex 0x00640000 to 0x006D0000 in Q16.16)
        for (i = 0; i < 10; i = i + 1) begin
            test_prices[i] = (100 + i) << 16;  // 100.0 to 109.0
        end
        
        // Prices from 90 to 99
        for (i = 10; i < 20; i = i + 1) begin
            test_prices[i] = (90 + (i - 10)) << 16;  // 90.0 to 99.0
        end
        
        // Repeat pattern with variations
        for (i = 20; i < 40; i = i + 1) begin
            test_prices[i] = (100 + (i - 20)) << 16;
        end
        
        for (i = 40; i < 60; i = i + 1) begin
            test_prices[i] = (90 + (i - 40)) << 16;
        end
        
        for (i = 60; i < 80; i = i + 1) begin
            test_prices[i] = (100 + (i - 60)) << 16;
        end
        
        for (i = 80; i < 100; i = i + 1) begin
            test_prices[i] = (90 + (i - 80)) << 16;
        end
        
        for (i = 100; i < 120; i = i + 1) begin
            test_prices[i] = (100 + (i - 100)) << 16;
        end
    end
    
    // Main test sequence
    initial begin
        $display("\n========================================");
        $display("MACD PARALLEL PIPELINE TEST");
        $display("========================================\n");
        
        // Initialize
        rst = 1;
        price = 0;
        price_valid = 0;
        cycle_count = 0;
        
        // Hold reset
        repeat(5) @(posedge clk);
        rst = 0;
        
        $display("time(ns) | cycle | price |  ema9     ema12    ema26    macd   signal   hist  | valid | pipeline_stage");
        $display("-----------------------------------------------------------------------------------------------------------");
        
        // Feed prices one per cycle
        for (i = 0; i < 120; i = i + 1) begin
            @(posedge clk);
            price = test_prices[i];
            price_valid = 1;
            cycle_count = i;
            
            // Display after clock edge settles
            #1;
            $display("%7d | %5d | %5.2f | %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f |   %1d   | %s",
                $time,
                cycle_count,
                fixed_to_real(test_prices[i]),
                fixed_to_real(ema9_out),
                fixed_to_real(ema12_out),
                fixed_to_real(ema26_out),
                fixed_to_real(macd_out),
                fixed_to_real(signal_out),
                fixed_to_real(histogram_out),
                result_valid,
                result_valid ? "OUTPUT_VALID" : "FILLING"
            );
            
            // Announce when result becomes valid
            if (result_valid && i == 40) begin
                $display(">>> RESULT VALID ASSERTED at cycle %0d <<<", cycle_count);
            end
        end
        
        // Continue for a few more cycles to see pipeline drain
        price_valid = 0;
        repeat(10) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
            #1;
            $display("%7d | %5d |  N/A  | %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f |   %1d   | DRAINING",
                $time,
                cycle_count,
                fixed_to_real(ema9_out),
                fixed_to_real(ema12_out),
                fixed_to_real(ema26_out),
                fixed_to_real(macd_out),
                fixed_to_real(signal_out),
                fixed_to_real(histogram_out),
                result_valid
            );
        end
        
        $display("\n========================");
        $display("Test complete!");
        $display("Final MACD value: %.4f", fixed_to_real(macd_out));
        $display("Final Signal Line: %.4f", fixed_to_real(signal_out));
        $display("Final Histogram: %.4f", fixed_to_real(histogram_out));
        $display("Final EMA9: %.4f", fixed_to_real(ema9_out));
        $display("Final EMA12: %.4f", fixed_to_real(ema12_out));
        $display("Final EMA26: %.4f", fixed_to_real(ema26_out));
        $display("========================\n");
        
        $finish;
    end
    
    // Timeout watchdog
    initial begin
        #2000000;  // 2ms timeout
        $display("\n*** ERROR: Simulation timeout! ***\n");
        $finish;
    end

endmodule