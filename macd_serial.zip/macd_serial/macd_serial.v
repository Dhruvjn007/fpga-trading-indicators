// macd_serial.v - CORRECTED HISTOGRAM VERSION
// Computes EMA(12), EMA(26), MACD = EMA12 - EMA26
// Then computes signal = EMA(9) of MACD, and histogram = MACD - signal
// Expects input price (signed 32-bit fixed point integer), and price_valid strobe.

module macd_serial(
  input  wire         clk,
  input  wire         reset,
  input  wire         start,
  input  wire         price_valid,
  input  wire signed [31:0] price,
  output reg signed [31:0] ema_9,        // EMA9 of price (for reference)
  output reg signed [31:0] ema_12,
  output reg signed [31:0] ema_26,
  output reg signed [31:0] macd,
  output reg signed [31:0] signal_line,  // EMA9 of MACD
  output reg signed [31:0] histogram,
  output reg               macd_valid
);

  // FSM states
  localparam IDLE               = 3'b000;
  localparam UPLOAD_PRICE       = 3'b001;
  localparam COMPUTE_EMA9       = 3'b010;
  localparam COMPUTE_EMA12      = 3'b011;
  localparam COMPUTE_EMA26      = 3'b100;
  localparam COMPUTE_MACD       = 3'b101;
  localparam COMPUTE_SIGNAL     = 3'b110;
  localparam COMPUTE_HISTOGRAM  = 3'b111;

  // Q16 fixed-point alphas (signed)
  // alpha_N = 2/(N+1) for proper EMA calculation
  localparam signed [31:0] alpha_9      = 32'h00003333; // 0.2 (Q16: 13107/65536)
  localparam signed [31:0] alpha_12     = 32'h000027AE; // ~0.1538 (10158/65536)
  localparam signed [31:0] alpha_26     = 32'h000012FC; // ~0.0741 (4860/65536)
  localparam signed [31:0] alpha_9_bar  = 32'h0000CCCD; // 0.8 (52429/65536)
  localparam signed [31:0] alpha_12_bar = 32'h0000D852; // ~0.8462 (55378/65536)
  localparam signed [31:0] alpha_26_bar = 32'h0000ED04; // ~0.9259 (60676/65536)

  reg [2:0] state, next_state;

  // internal registers
  reg signed [31:0] curr_price;
  reg [15:0] sample_count;
  reg first_sample;

  // 64-bit temp arithmetic
  reg signed [63:0] sum64;

  // combinational next-state logic
  always @(*) begin
    next_state = state;
    case (state)
      IDLE: begin
        if (start && price_valid) next_state = UPLOAD_PRICE;
      end

      UPLOAD_PRICE:         next_state = COMPUTE_EMA9;
      COMPUTE_EMA9:         next_state = COMPUTE_EMA12;
      COMPUTE_EMA12:        next_state = COMPUTE_EMA26;
      COMPUTE_EMA26:        next_state = COMPUTE_MACD;
      COMPUTE_MACD:         next_state = COMPUTE_SIGNAL;
      COMPUTE_SIGNAL:       next_state = COMPUTE_HISTOGRAM;
      COMPUTE_HISTOGRAM:    next_state = IDLE;

      default: next_state = IDLE;
    endcase
  end

  // synchronous state & datapath updates
  always @(posedge clk or posedge reset) begin
    if (reset) begin
      state        <= IDLE;
      sample_count <= 0;
      curr_price   <= 0;
      ema_9        <= 0;
      ema_12       <= 0;
      ema_26       <= 0;
      macd         <= 0;
      signal_line  <= 0;
      histogram    <= 0;
      macd_valid   <= 0;
      sum64        <= 0;
      first_sample <= 1;
    end else begin
      state <= next_state;

      case (state)
        IDLE: begin
          // Hold macd_valid
        end

        UPLOAD_PRICE: begin
          curr_price <= price;
        end

        COMPUTE_EMA9: begin
          if (first_sample) begin
            // First sample - initialize to current price
            ema_9 <= curr_price;
          end else begin
            // EMA formula: EMA_new = alpha * price_new + (1-alpha) * EMA_old
            sum64 = (alpha_9 * curr_price) + (alpha_9_bar * ema_9);
            ema_9 <= sum64[47:16]; // Extract middle 32 bits after 32x32 multiply
          end
        end

        COMPUTE_EMA12: begin
          if (first_sample) begin
            ema_12 <= curr_price;
          end else begin
            sum64 = (alpha_12 * curr_price) + (alpha_12_bar * ema_12);
            ema_12 <= sum64[47:16];
          end
        end

        COMPUTE_EMA26: begin
          if (first_sample) begin
            ema_26 <= curr_price;
          end else begin
            sum64 = (alpha_26 * curr_price) + (alpha_26_bar * ema_26);
            ema_26 <= sum64[47:16];
          end
        end

        COMPUTE_MACD: begin
          macd <= ema_12 - ema_26;
        end

        COMPUTE_SIGNAL: begin
          // Compute EMA(9) of MACD (signal line)
          if (first_sample) begin
            signal_line <= macd;
          end else begin
            sum64 = (alpha_9 * macd) + (alpha_9_bar * signal_line);
            signal_line <= sum64[47:16];
          end
        end

        COMPUTE_HISTOGRAM: begin
          // Histogram is MACD - signal_line (NOT absolute value)
          histogram <= macd - signal_line;
          
          // Clear first sample flag after first processing
          first_sample <= 0;
          
          // Increment sample counter
          sample_count <= sample_count + 1;
          
          // Set macd_valid when we reach sample 26
          if ((sample_count + 1) == 32) begin
            macd_valid <= 1;
          end
        end

        default: ;
      endcase
    end
  end

endmodule