// top_design.v
// Integrates price_reader and macd_serial
// Reads prices from hex file, streams them sequentially into MACD computation.
// -----------------------------------------------------------------------------
module top_design #(
    parameter DATA_WIDTH = 32,
    parameter DEPTH      = 256,
    parameter FILE_NAME  = "prices.hex"
)(
    input  wire clk,
    input  wire reset,
    input  wire start,

    // Outputs
    output wire signed [DATA_WIDTH-1:0] price,
    output wire signed [DATA_WIDTH-1:0] ema_9,
    output wire signed [DATA_WIDTH-1:0] ema_12,
    output wire signed [DATA_WIDTH-1:0] ema_26,
    output wire signed [DATA_WIDTH-1:0] macd,
    output wire signed [DATA_WIDTH-1:0] histogram,
    output wire macd_valid,
    output wire done
);

    // Internal signals
    wire price_valid_internal;
    wire signed [DATA_WIDTH-1:0] price_internal;

    // ---------------------------------------------------------------
    // Instance 1: price_reader
    // ---------------------------------------------------------------
    price_reader #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(DEPTH),
        .FILE_NAME(FILE_NAME)
    ) price_reader_inst (
        .clk(clk),
        .start(start),
        .price(price_internal),
        .done(done),
        .price_valid(price_valid_internal)
    );

    // ---------------------------------------------------------------
    // Instance 2: macd_serial
    // ---------------------------------------------------------------
    macd_serial macd_serial_inst (
        .clk(clk),
        .reset(reset),
        .start(start),
        .price_valid(price_valid_internal),
        .price(price_internal),
        .ema_9(ema_9),
        .ema_12(ema_12),
        .ema_26(ema_26),
        .macd(macd),
        .histogram(histogram),
        .macd_valid(macd_valid)
    );

    // ---------------------------------------------------------------
    // Output wiring
    // ---------------------------------------------------------------
    assign price = price_internal;  // expose current price

endmodule