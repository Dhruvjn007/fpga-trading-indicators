module tb_top_design;
    reg clk = 0;
    reg reset = 0;
    reg start = 0;

    wire signed [31:0] price, ema_9, ema_12, ema_26, macd, histogram;
    wire macd_valid, done;

    always #50 clk = ~clk;

    top_design #(.DEPTH(100), .FILE_NAME("prices.hex")) dut (
        .clk(clk), .reset(reset), .start(start),
        .price(price),
        .ema_9(ema_9), .ema_12(ema_12), .ema_26(ema_26),
        .macd(macd), .histogram(histogram),
        .macd_valid(macd_valid), .done(done)
    );

    initial begin
        $dumpfile("macd_wave.vcd");
        $dumpvars(0, tb_top_design);

        reset = 1; #10; reset = 0;
        #10 start = 1;
        #2000 $finish;
    end
	 always @(posedge clk) begin
    $display("Time=%0t | reset=%b start=%b price_valid=%b price=%h ema_9=%h ema_12=%h ema_26=%h macd=%h histogram=%h macd_valid=%b",
             $time, reset, start, price_valid, price, ema_9, ema_12, ema_26, macd, histogram, macd_valid);
    end

endmodule