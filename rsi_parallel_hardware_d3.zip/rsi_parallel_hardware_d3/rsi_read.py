import serial
import time

# ==== CONFIGURE THIS PART ======================================
PORT = "COM5"        # <-- CHANGE THIS to your Basys3 COM port
BAUD = 115200        # Must match uart_tx BAUD_RATE
# ===============================================================


def main():
    print(f"Opening serial port {PORT} at {BAUD} baud...")
    try:
        ser = serial.Serial(
            PORT,
            BAUD,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=1.0,       # seconds
        )
    except serial.SerialException as e:
        print(f"Error opening serial port: {e}")
        return

    print("Connected.")
    print("Press BTN_C to reset FPGA, BTN_U to start RSI run.")
    print("Waiting for lines like:  D:014 RSI:87.50 DEC:B/H/S\n")

    # clear any old garbage
    ser.reset_input_buffer()

    try:
        while True:
            line = ser.readline()  # reads until '\n' from FPGA
            if not line:
                continue

            # decode bytes -> string
            text = line.decode("ascii", errors="replace").strip()

            # simple pretty print
            print(text)

    except KeyboardInterrupt:
        print("\nStopping...")

    finally:
        ser.close()
        print("Serial port closed.")


if __name__ == "__main__":
    main()
