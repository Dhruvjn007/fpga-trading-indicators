//==============================================================================
// COMPLETE RSI SYSTEM - ALL BUGS FIXED
// File 1 of 3: rsi_calculator_final.v
//==============================================================================

module rsi_calculator #(
    parameter DATA_WIDTH = 32,      
    parameter FRAC_BITS = 16        
) (
    input wire clk,
    input wire rst_n,               
    input wire start,               
    input wire [DATA_WIDTH-1:0] close_price,  
    output reg [DATA_WIDTH-1:0] rsi_value,    
    output reg valid,               
    output reg [1:0] decision       
);

    localparam IDLE = 3'd0;
    localparam ACCUMULATE = 3'd1;   
    localparam COMPUTE_INIT = 3'd2; 
    localparam WAIT_DIV = 3'd3;     
    localparam RUNNING = 3'd4;      
    
    reg [2:0] state;
    reg [7:0] day_counter;          
    
    reg [DATA_WIDTH-1:0] prev_price;
    reg [DATA_WIDTH-1:0] current_gain;
    reg [DATA_WIDTH-1:0] current_loss;
    
    reg [DATA_WIDTH+4-1:0] gain_sum;  
    reg [DATA_WIDTH+4-1:0] loss_sum;
    
    reg [DATA_WIDTH-1:0] avg_gain;
    reg [DATA_WIDTH-1:0] avg_loss;
    reg [DATA_WIDTH-1:0] avg_gain_next;
    reg [DATA_WIDTH-1:0] avg_loss_next;
    
    reg div_start;
    reg div_start_issued;           
    wire div_valid;
    wire [DATA_WIDTH-1:0] rs_value; 
    wire div_by_zero;               
    
    reg [DATA_WIDTH-1:0] prev_rsi;
    reg [DATA_WIDTH-1:0] computed_rsi;
    reg [DATA_WIDTH-1:0] new_rsi;
    
    localparam [DATA_WIDTH-1:0] RSI_MAX = 100 << FRAC_BITS;  
    localparam [DATA_WIDTH-1:0] RSI_MIN = 32'd0;                  
    localparam [DATA_WIDTH-1:0] ONE = 1 << FRAC_BITS;         
    
    always @(*) begin
        if (close_price >= prev_price) begin
            current_gain = close_price - prev_price;
            current_loss = 32'd0;
        end else begin
            current_gain = 32'd0;
            current_loss = prev_price - close_price;
        end
    end
    
    always @(*) begin
        avg_gain_next = avg_gain;
        avg_loss_next = avg_loss;
        
        if (state == RUNNING && start && !div_start_issued) begin
            avg_gain_next = ((avg_gain * 13 + current_gain) * 4681) >> 16;
            avg_loss_next = ((avg_loss * 13 + current_loss) * 4681) >> 16;
        end
    end
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            day_counter <= 8'd0;
            prev_price <= 32'd0;
            gain_sum <= 36'd0;
            loss_sum <= 36'd0;
            avg_gain <= 32'd0;
            avg_loss <= 32'd0;
            rsi_value <= 50 << FRAC_BITS;
            valid <= 1'b0;
            div_start <= 1'b0;
            div_start_issued <= 1'b0;
            prev_rsi <= 50 << FRAC_BITS;
            decision <= 2'b00;
            computed_rsi <= 32'd0;
            new_rsi <= 32'd0;
            
        end else begin
            div_start <= 1'b0;
            valid <= 1'b0;
            
            case (state)
                IDLE: begin
                    if (start) begin
                        prev_price <= close_price;
                        day_counter <= 8'd0;
                        gain_sum <= 36'd0;
                        loss_sum <= 36'd0;
                        state <= ACCUMULATE;
                    end
                end
                
                ACCUMULATE: begin
                    if (start) begin  
                        gain_sum <= gain_sum + current_gain;
                        loss_sum <= loss_sum + current_loss;
                        
                        prev_price <= close_price;
                        day_counter <= day_counter + 8'd1;
                        
                        if (day_counter == 8'd13) begin
                            state <= COMPUTE_INIT;
                        end
                    end
                end
                
                COMPUTE_INIT: begin
                    avg_gain <= (gain_sum * 4681) >> 16;
                    avg_loss <= (loss_sum * 4681) >> 16;
                    
                    day_counter <= 8'd14;
                    div_start_issued <= 1'b0;
                    state <= WAIT_DIV;
                end
                
                WAIT_DIV: begin
                    if (!div_start_issued) begin
                        if (avg_loss == 32'd0) begin
                            rsi_value <= RSI_MAX;
                            valid <= 1'b1;
                            prev_rsi <= RSI_MAX;
                            decision <= 2'b00;
                            state <= RUNNING;
                        end else begin
                            div_start <= 1'b1;
                            div_start_issued <= 1'b1;
                        end
                    end else if (div_valid) begin
                        computed_rsi = calculate_rsi_clamped(rs_value);
                        
                        rsi_value <= computed_rsi;
                        valid <= 1'b1;
                        prev_rsi <= computed_rsi;
                        decision <= 2'b00;
                        div_start_issued <= 1'b0;
                        state <= RUNNING;
                    end
                end
                
                RUNNING: begin
                    if (start && !div_start_issued) begin
                        avg_gain <= avg_gain_next;
                        avg_loss <= avg_loss_next;
                        
                        prev_price <= close_price;
                        day_counter <= day_counter + 8'd1;
                        
                        if (avg_loss_next == 32'd0) begin
                            rsi_value <= RSI_MAX;
                            valid <= 1'b1;
                            
                            if (RSI_MAX > prev_rsi) 
                                decision <= 2'b01;
                            else if (RSI_MAX < prev_rsi)
                                decision <= 2'b10;
                            else
                                decision <= 2'b00;
                                
                            prev_rsi <= RSI_MAX;
                        end else begin
                            div_start <= 1'b1;
                            div_start_issued <= 1'b1;
                        end
                    end
                    
                    if (div_valid) begin
                        new_rsi = calculate_rsi_clamped(rs_value);
                        
                        if (new_rsi > prev_rsi) begin
                            decision <= 2'b01;
                        end else if (new_rsi < prev_rsi) begin
                            decision <= 2'b10;
                        end else begin
                            decision <= 2'b00;
                        end
                        
                        rsi_value <= new_rsi;
                        prev_rsi <= new_rsi;
                        valid <= 1'b1;
                        div_start_issued <= 1'b0;
                    end
                end
                
                default: state <= IDLE;
            endcase
        end
    end
    
    function [DATA_WIDTH-1:0] calculate_rsi_clamped;
        input [DATA_WIDTH-1:0] rs;
        reg [DATA_WIDTH*2-1:0] numerator;
        reg [DATA_WIDTH-1:0] denominator;
        reg [DATA_WIDTH-1:0] result;
        begin
            denominator = ONE + rs;
            numerator = RSI_MAX * rs;
            
            if (denominator != 32'd0) begin
                result = numerator / denominator;
            end else begin
                result = RSI_MAX;
            end
            
            if (result > RSI_MAX) begin
                calculate_rsi_clamped = RSI_MAX;
            end else if (result < RSI_MIN) begin
                calculate_rsi_clamped = RSI_MIN;
            end else begin
                calculate_rsi_clamped = result;
            end
        end
    endfunction
    
    pipelined_divider_d3_exact #(
        .DATA_WIDTH(DATA_WIDTH),
        .FRAC_BITS(FRAC_BITS),
        .LATENCY(32)
    ) divider (
        .clk(clk),
        .rst_n(rst_n),
        .start(div_start),
        .dividend(avg_gain_next),
        .divisor(avg_loss_next),
        .quotient(rs_value),
        .valid(div_valid),
        .div_by_zero(div_by_zero)
    );

endmodule
