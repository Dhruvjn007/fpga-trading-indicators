//==============================================================================
// Price ROM - Stores 200 test prices
// File: price_rom.v
//==============================================================================

module price_rom #(
    parameter DATA_WIDTH = 32,
    parameter NUM_PRICES = 200,
    parameter ADDR_WIDTH = 8  // 2^8 = 256 addresses
) (
    input wire clk,
    input wire [ADDR_WIDTH-1:0] addr,
    output reg [DATA_WIDTH-1:0] price
);

    // Price storage - Fixed point format (16.16)
    // Base price around 100.00 = 100 << 16 = 6553600
    reg [DATA_WIDTH-1:0] price_mem [0:NUM_PRICES-1];
    
    integer i;
    real base_price, curr_price, noise;
    
    initial begin
        base_price = 100.0;
        
        // Generate 200 prices with Up/Sideways/Down pattern
        for (i = 0; i < NUM_PRICES; i = i + 1) begin
            if (i < 50) begin
                // Days 0-49: UP trend
                noise = $sin(i * 0.30) * 0.8;
                curr_price = base_price + i * 0.5 + noise;
            end 
            else if (i < 120) begin
                // Days 50-119: SIDEWAYS/CHOPPY
                noise = $sin(i * 0.70) * 1.2;
                curr_price = base_price + 50 * 0.5 + (i-50) * 0.05 + noise;
            end 
            else begin
                // Days 120-199: DOWN trend
                noise = $sin(i * 0.40) * 0.8;
                curr_price = base_price + 50 * 0.5 + 70 * 0.05 - (i-120) * 0.6 + noise;
            end
            
            // Convert to fixed-point (16.16 format)
            price_mem[i] = $rtoi(curr_price * 65536.0);
            
            // Debug: Print first 10 and last 10 prices
            if (i < 10 || i >= NUM_PRICES - 10) begin
                $display("Price[%3d] = %7.2f (0x%08h)", i, curr_price, price_mem[i]);
            end
        end
    end
    
    always @(posedge clk) begin
        if (addr < NUM_PRICES)
            price <= price_mem[addr];
        else
            price <= 32'd0;
    end

endmodule