module pipelined_divider_d3_exact #(
    parameter DATA_WIDTH = 32,
    parameter FRAC_BITS = 16,
    parameter LATENCY = 32
) (
    input wire clk,
    input wire rst_n,
    input wire start,
    input wire [DATA_WIDTH-1:0] dividend,
    input wire [DATA_WIDTH-1:0] divisor,
    output wire [DATA_WIDTH-1:0] quotient,
    output wire valid,
    output wire div_by_zero
);

    integer i;
    reg [DATA_WIDTH-1:0] q_pipe [0:LATENCY-1];
    reg v_pipe [0:LATENCY-1];
    reg z_pipe [0:LATENCY-1];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (i = 0; i < LATENCY; i = i + 1) begin
                q_pipe[i] <= 0;
                v_pipe[i] <= 0;
                z_pipe[i] <= 0;
            end
        end else begin
            if (start) begin
                if (divisor == 0) begin
                    q_pipe[0] <= {DATA_WIDTH{1'b1}};
                    v_pipe[0] <= 1'b1;
                    z_pipe[0] <= 1'b1;
                end else begin
                    q_pipe[0] <= ((dividend << FRAC_BITS) / divisor);
                    v_pipe[0] <= 1'b1;
                    z_pipe[0] <= 1'b0;
                end
            end else begin
                q_pipe[0] <= 0;
                v_pipe[0] <= 1'b0;
                z_pipe[0] <= 1'b0;
            end

            for (i = 1; i < LATENCY; i = i + 1) begin
                q_pipe[i] <= q_pipe[i-1];
                v_pipe[i] <= v_pipe[i-1];
                z_pipe[i] <= z_pipe[i-1];
            end
        end
    end

    assign quotient = q_pipe[LATENCY-1];
    assign valid = v_pipe[LATENCY-1];
    assign div_by_zero = z_pipe[LATENCY-1];

endmodule