//==============================================================================
// RSI FPGA Top Level - Basys 3 Implementation (100 MHz in, 25 MHz internal)
//==============================================================================

module rsi_fpga_top (
    input  wire        clk_100mhz,  // 100MHz clock from Basys 3
    input  wire        btnC,        // Center button - reset (active high)
    input  wire        btnU,        // Up button - start
    output wire [15:0] led,         // LEDs for status
    output wire        uart_tx      // UART TX pin
);

    // Parameters
    parameter DATA_WIDTH = 32;
    parameter FRAC_BITS  = 16;
    parameter NUM_PRICES = 200;

    //==================================================================
    // Reset (internal active-low)
    //==================================================================
    wire rst_n = ~btnC;

    //==================================================================
    // Clock divider: 100 MHz -> 25 MHz
    //==================================================================
    reg [1:0] clk_div_counter;
    reg       clk_25mhz;

    always @(posedge clk_100mhz or negedge rst_n) begin
        if (!rst_n) begin
            clk_div_counter <= 2'd0;
            clk_25mhz       <= 1'b0;
        end else begin
            clk_div_counter <= clk_div_counter + 2'd1;
            if (clk_div_counter == 2'd0)
                clk_25mhz <= ~clk_25mhz;
        end
    end

    // Internal system clock
    wire clk = clk_25mhz;

    //==================================================================
    // Internal signals
    //==================================================================
    reg                  start;
    reg  [7:0]           price_addr;
    wire [DATA_WIDTH-1:0] close_price;
    wire [DATA_WIDTH-1:0] rsi_value;
    wire                 rsi_valid;
    wire [1:0]           decision;

    // UART
    wire [7:0]           uart_data;
    wire                 uart_start;
    wire                 uart_busy;

    // Button debouncing
    reg  [19:0]          btnU_debounce;
    reg                  btnU_prev, btnU_sync;
    wire                 btnU_pulse;

    // Control FSM
    localparam S_IDLE = 2'd0;
    localparam S_FEED = 2'd1;
    localparam S_WAIT = 2'd2;
    localparam S_DONE = 2'd3;

    reg [1:0] state;
    reg [7:0] day_counter;
    reg [7:0] wait_counter;

    //==================================================================
    // LED status indicators
    //==================================================================
    assign led[15:14] = state;
    assign led[13]    = rsi_valid;
    assign led[12]    = uart_busy;
    assign led[11:10] = decision;
    assign led[9:8]   = rsi_value[17:16];  // Show top bits of RSI
    assign led[7:0]   = day_counter;

    //==================================================================
    // Button Debouncing for Start Button
    //==================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            btnU_debounce <= 20'd0;
            btnU_prev     <= 1'b0;
            btnU_sync     <= 1'b0;
        end else begin
            btnU_sync <= btnU;

            if (btnU_sync == btnU_prev) begin
                if (btnU_debounce < 20'hFFFFF)
                    btnU_debounce <= btnU_debounce + 1;
            end else begin
                btnU_debounce <= 20'd0;
                btnU_prev     <= btnU_sync;
            end
        end
    end

    assign btnU_pulse = (btnU_debounce == 20'hFFFFF) && btnU_sync && !btnU_prev;

    //==================================================================
    // Control FSM - Manages price feeding
    //==================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state        <= S_IDLE;
            start        <= 1'b0;
            price_addr   <= 8'd0;
            day_counter  <= 8'd0;
            wait_counter <= 8'd0;
        end else begin
            start <= 1'b0;  // default

            case (state)
                S_IDLE: begin
                    if (btnU_pulse) begin
                        price_addr  <= 8'd0;
                        day_counter <= 8'd0;
                        state       <= S_FEED;
                    end
                end

                S_FEED: begin
                    start        <= 1'b1;
                    wait_counter <= 8'd0;
                    state        <= S_WAIT;
                end

                S_WAIT: begin
                    wait_counter <= wait_counter + 1;

                    // After day 14, RSI is valid and divider is used
                    if (day_counter >= 8'd14) begin
                        if (wait_counter >= 8'd40) begin  // 32-cycle divider + margin
                            if (day_counter < NUM_PRICES - 1) begin
                                price_addr  <= price_addr + 1;
                                day_counter <= day_counter + 1;
                                state       <= S_FEED;
                            end else begin
                                state <= S_DONE;
                            end
                        end
                    end else begin
                        // First 14 days: no divider
                        if (wait_counter >= 8'd2) begin
                            price_addr  <= price_addr + 1;
                            day_counter <= day_counter + 1;
                            state       <= S_FEED;
                        end
                    end
                end

                S_DONE: begin
                    // Press btnU again to restart
                    if (btnU_pulse)
                        state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

    //==================================================================
    // Module Instantiations
    //==================================================================

    // Price ROM
    price_rom #(
        .DATA_WIDTH (DATA_WIDTH),
        .NUM_PRICES (NUM_PRICES)
    ) u_price_rom (
        .clk   (clk),
        .addr  (price_addr),
        .price (close_price)
    );

    // RSI Calculator
    rsi_calculator #(
        .DATA_WIDTH (DATA_WIDTH),
        .FRAC_BITS  (FRAC_BITS)
    ) u_rsi (
        .clk         (clk),
        .rst_n       (rst_n),
        .start       (start),
        .close_price (close_price),
        .rsi_value   (rsi_value),
        .valid       (rsi_valid),
        .decision    (decision)
    );

    // UART Formatter
    rsi_uart_formatter #(
        .DATA_WIDTH (DATA_WIDTH),
        .FRAC_BITS  (FRAC_BITS)
    ) u_formatter (
        .clk        (clk),
        .rst_n      (rst_n),
        .rsi_value  (rsi_value),
        .decision   (decision),
        .rsi_valid  (rsi_valid),
        .day_number (day_counter),
        .uart_data  (uart_data),
        .uart_start (uart_start),
        .uart_busy  (uart_busy)
    );

    // UART Transmitter - NOTE: CLK_FREQ matches internal 25 MHz
    uart_tx #(
        .CLK_FREQ (25_000_000),
        .BAUD_RATE(115200)
    ) u_uart_tx (
        .clk      (clk),
        .rst_n    (rst_n),
        .data_in  (uart_data),
        .tx_start (uart_start),
        .tx       (uart_tx),
        .tx_busy  (uart_busy)
    );

endmodule
