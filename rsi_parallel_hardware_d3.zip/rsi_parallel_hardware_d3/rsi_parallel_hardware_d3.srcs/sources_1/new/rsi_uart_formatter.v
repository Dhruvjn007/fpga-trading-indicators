//==============================================================================
// RSI UART Formatter - Converts RSI output to UART messages
// File: rsi_uart_formatter.v
//==============================================================================

module rsi_uart_formatter #(
    parameter DATA_WIDTH = 32,
    parameter FRAC_BITS = 16
) (
    input wire clk,
    input wire rst_n,
    
    // RSI inputs
    input wire [DATA_WIDTH-1:0] rsi_value,
    input wire [1:0] decision,
    input wire rsi_valid,
    input wire [7:0] day_number,
    
    // UART interface
    output reg [7:0] uart_data,
    output reg uart_start,
    input wire uart_busy
);

    // Message format: "D:XXX RSI:YY.YY DEC:Z\n"
    // Total ~23 bytes per message
    
    localparam IDLE = 4'd0;
    localparam SEND_D = 4'd1;
    localparam SEND_DAY = 4'd2;
    localparam SEND_RSI = 4'd3;
    localparam SEND_VAL = 4'd4;
    localparam SEND_DEC = 4'd5;
    localparam SEND_NEWLINE = 4'd6;
    localparam WAIT_UART = 4'd7;
    
    reg [3:0] state;
    reg [4:0] char_index;
    reg [7:0] day_buf [0:2];      // 3 digits for day
    reg [7:0] rsi_int_buf [0:1];  // 2 digits for RSI integer
    reg [7:0] rsi_frac_buf [0:1]; // 2 digits for RSI fraction
    reg [7:0] dec_char;
    
    reg [DATA_WIDTH-1:0] rsi_reg;
    reg [1:0] decision_reg;
    reg [7:0] day_reg;
    
    integer rsi_int, rsi_frac, temp_day;
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            uart_start <= 1'b0;
            char_index <= 5'd0;
            rsi_reg <= 32'd0;
            decision_reg <= 2'd0;
            day_reg <= 8'd0;
        end else begin
            uart_start <= 1'b0;
            
            case (state)
                IDLE: begin
                    if (rsi_valid && !uart_busy) begin
                        // Capture values
                        rsi_reg <= rsi_value;
                        decision_reg <= decision;
                        day_reg <= day_number;
                        
                        // Convert RSI to decimal
                        rsi_int = rsi_value >> FRAC_BITS;
                        rsi_frac = ((rsi_value & 16'hFFFF) * 100) >> FRAC_BITS;
                        
                        // Convert to ASCII digits
                        rsi_int_buf[0] = 8'd48 + (rsi_int / 10);
                        rsi_int_buf[1] = 8'd48 + (rsi_int % 10);
                        rsi_frac_buf[0] = 8'd48 + (rsi_frac / 10);
                        rsi_frac_buf[1] = 8'd48 + (rsi_frac % 10);
                        
                        // Convert day to ASCII
                        temp_day = day_number;
                        day_buf[0] = 8'd48 + (temp_day / 100);
                        temp_day = temp_day % 100;
                        day_buf[1] = 8'd48 + (temp_day / 10);
                        day_buf[2] = 8'd48 + (temp_day % 10);
                        
                        // Convert decision
                        case (decision)
                            2'b01: dec_char = 8'd66;  // 'B' for BUY
                            2'b10: dec_char = 8'd83;  // 'S' for SELL
                            default: dec_char = 8'd72; // 'H' for HOLD
                        endcase
                        
                        char_index <= 5'd0;
                        state <= SEND_D;
                    end
                end
                
                SEND_D: begin
                    if (!uart_busy) begin
                        case (char_index)
                            0: uart_data <= 8'd68;  // 'D'
                            1: uart_data <= 8'd58;  // ':'
                            2: uart_data <= day_buf[0];
                            3: uart_data <= day_buf[1];
                            4: uart_data <= day_buf[2];
                            5: uart_data <= 8'd32;  // space
                            default: uart_data <= 8'd32;
                        endcase
                        
                        uart_start <= 1'b1;
                        
                        if (char_index < 5) begin
                            char_index <= char_index + 1;
                            state <= WAIT_UART;
                        end else begin
                            char_index <= 5'd0;
                            state <= SEND_RSI;
                        end
                    end
                end
                
                SEND_RSI: begin
                    if (!uart_busy) begin
                        case (char_index)
                            0: uart_data <= 8'd82;  // 'R'
                            1: uart_data <= 8'd83;  // 'S'
                            2: uart_data <= 8'd73;  // 'I'
                            3: uart_data <= 8'd58;  // ':'
                            default: uart_data <= 8'd32;
                        endcase
                        
                        uart_start <= 1'b1;
                        
                        if (char_index < 3) begin
                            char_index <= char_index + 1;
                            state <= WAIT_UART;
                        end else begin
                            char_index <= 5'd0;
                            state <= SEND_VAL;
                        end
                    end
                end
                
                SEND_VAL: begin
                    if (!uart_busy) begin
                        case (char_index)
                            0: uart_data <= rsi_int_buf[0];
                            1: uart_data <= rsi_int_buf[1];
                            2: uart_data <= 8'd46;  // '.'
                            3: uart_data <= rsi_frac_buf[0];
                            4: uart_data <= rsi_frac_buf[1];
                            5: uart_data <= 8'd32;  // space
                            default: uart_data <= 8'd32;
                        endcase
                        
                        uart_start <= 1'b1;
                        
                        if (char_index < 5) begin
                            char_index <= char_index + 1;
                            state <= WAIT_UART;
                        end else begin
                            char_index <= 5'd0;
                            state <= SEND_DEC;
                        end
                    end
                end
                
                SEND_DEC: begin
                    if (!uart_busy) begin
                        case (char_index)
                            0: uart_data <= 8'd68;  // 'D'
                            1: uart_data <= 8'd69;  // 'E'
                            2: uart_data <= 8'd67;  // 'C'
                            3: uart_data <= 8'd58;  // ':'
                            4: uart_data <= dec_char;
                            default: uart_data <= 8'd32;
                        endcase
                        
                        uart_start <= 1'b1;
                        
                        if (char_index < 4) begin
                            char_index <= char_index + 1;
                            state <= WAIT_UART;
                        end else begin
                            state <= SEND_NEWLINE;
                        end
                    end
                end
                
                SEND_NEWLINE: begin
                    if (!uart_busy) begin
                        uart_data <= 8'd10;  // '\n'
                        uart_start <= 1'b1;
                        state <= WAIT_UART;
                    end
                end
                
                WAIT_UART: begin
                    if (!uart_busy) begin
                        if (state == SEND_NEWLINE) begin
                            state <= IDLE;
                        end else begin
                            // Return to appropriate state
                            if (char_index == 0 && state == SEND_D)
                                state <= SEND_RSI;
                            else if (char_index == 0 && state == SEND_RSI)
                                state <= SEND_VAL;
                            else if (char_index == 0 && state == SEND_VAL)
                                state <= SEND_DEC;
                            else
                                state <= state;  // Stay in current send state
                        end
                    end
                end
                
                default: state <= IDLE;
            endcase
        end
    end

endmodule